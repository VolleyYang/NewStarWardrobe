package com.yangshenglong.newstarwardrobe.shopping.adapter;

/**
 * Created by xiaoBu on 16/12/28.
 */

public interface MyClick {

    void myListener(int pos);

}
