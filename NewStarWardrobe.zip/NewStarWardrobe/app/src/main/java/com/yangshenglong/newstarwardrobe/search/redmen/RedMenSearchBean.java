package com.yangshenglong.newstarwardrobe.search.redmen;

import java.util.List;

/**
 * Created by CST on 16/12/24.
 */

public class RedMenSearchBean {

    /**
     * message :
     * data : {"items":[{"component":{"componentType":"hongrenSearch","userName":"minilady","userTypeName":"穿搭达人","description":"在韩国学习生活7年，酷爱韩国的时尚文化，耳濡目染的同时自己对韩国的时尚文化有独特的见解，希望把自己平时看到的和听到的好东西传递给明星衣橱的MM们，传递美美的正能量。","userAvatar":"http://api.upload3.pimg.cn/user_upload/b8a77c00f6b14e9896cd61861985a62c.jpeg_thumb_120x%3E_.jpeg","action":{"type":"user","actionType":"detail","id":1169728,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u5728\\u97e9\\u56fd\\u5b66\\u4e60\\u751f\\u6d3b7\\u5e74\\uff0c\\u9177\\u7231\\u97e9\\u56fd\\u7684\\u65f6\\u5c1a\\u6587\\u5316\\uff0c\\u8033\\u6fe1\\u76ee\\u67d3\\u7684\\u540c\\u65f6\\u81ea\\u5df1\\u5bf9\\u97e9\\u56fd\\u7684\\u65f6\\u5c1a\\u6587\\u5316\\u6709\\u72ec\\u7279\\u7684\\u89c1\\u89e3\\uff0c\\u5e0c\\u671b\\u628a\\u81ea\\u5df1\\u5e73\\u65f6\\u770b\\u5230\\u7684\\u548c\\u542c\\u5230\\u7684\\u597d\\u4e1c\\u897f\\u4f20\\u9012\\u7ed9\\u660e\\u661f\\u8863\\u6a71\\u7684MM\\u4eec\\uff0c\\u4f20\\u9012\\u7f8e\\u7f8e\\u7684\\u6b63\\u80fd\\u91cf\\u3002\",\"fans_count\":3,\"name\":\"minilady\",\"avatar_img_id\":2237462,\"id\":1169728,\"avatar\":\"http:\\/\\/tp3.sinaimg.cn\\/1663448522\\/180\\/40012377904\\/0\",\"type\":\"\\u7a7f\\u642d\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:13.091385\"}"}}},{"component":{"componentType":"hongrenSearch","userName":"a布","userTypeName":"乐活达人","description":"时尚店主","userAvatar":"http://mxycforum.u.qiniudn.com/2014-09-17-61c61d02d00a0f0642cb17171dc48854","action":{"type":"user","actionType":"detail","id":326808,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u65f6\\u5c1a\\u5e97\\u4e3b\",\"fans_count\":2,\"name\":\"a\\u5e03\",\"avatar_img_id\":338920,\"id\":326808,\"avatar\":\"http:\\/\\/qzapp.qlogo.cn\\/qzapp\\/100276062\\/A29357CD22303383D73A620835FE155B\\/100\",\"type\":\"\\u4e50\\u6d3b\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:06.743357\"}"}}},{"component":{"componentType":"hongrenSearch","userName":"miss曼a_a","userTypeName":"穿搭达人","description":"人气时尚博主，时尚撰稿人","userAvatar":"http://tp3.sinaimg.cn/2272814962/180/40053713207/0","action":{"type":"user","actionType":"detail","id":1761455,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u4eba\\u6c14\\u65f6\\u5c1a\\u535a\\u4e3b\\uff0c\\u65f6\\u5c1a\\u64b0\\u7a3f\\u4eba\",\"fans_count\":2,\"name\":\"miss\\u66fca_a\",\"avatar_img_id\":0,\"id\":1761455,\"avatar\":\"http:\\/\\/tp3.sinaimg.cn\\/2272814962\\/180\\/40053713207\\/0\",\"type\":\"\\u7a7f\\u642d\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:07.372844\"}"}}},{"component":{"componentType":"hongrenSearch","userName":"A Super XIN","userTypeName":"乐活达人","description":"时尚店主","userAvatar":"http://api.upload1.pimg.cn/user_upload/ffab7bddcb4d459791cde2b9330fbfa5.jpeg_thumb_120x%3E_.jpeg","action":{"type":"user","actionType":"detail","id":958111,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u65f6\\u5c1a\\u5e97\\u4e3b\",\"fans_count\":2,\"name\":\"A Super XIN\",\"avatar_img_id\":1449870,\"id\":958111,\"avatar\":\"http:\\/\\/tp3.sinaimg.cn\\/2242238730\\/180\\/5688898172\\/0\",\"type\":\"\\u4e50\\u6d3b\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:07.667867\"}"}}},{"component":{"componentType":"hongrenSearch","userName":"安缇娜A-tina","userTypeName":"穿搭达人","description":"即是朋友眼中的穿搭达人，又是一名时尚店主，还是一位在校生哦！","userAvatar":"http://api.upload2.pimg.cn/user_upload/d062e70be5e74d4684c5be1855df4850.jpeg_thumb_120x%3E_.jpeg","action":{"type":"user","actionType":"detail","id":4504999,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u5373\\u662f\\u670b\\u53cb\\u773c\\u4e2d\\u7684\\u7a7f\\u642d\\u8fbe\\u4eba\\uff0c\\u53c8\\u662f\\u4e00\\u540d\\u65f6\\u5c1a\\u5e97\\u4e3b\\uff0c\\u8fd8\\u662f\\u4e00\\u4f4d\\u5728\\u6821\\u751f\\u54e6\\uff01\",\"fans_count\":0,\"name\":\"\\u5b89\\u7f07\\u5a1cA-tina\",\"avatar_img_id\":917584,\"id\":4504999,\"avatar\":\"\",\"type\":\"\\u7a7f\\u642d\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:13.872323\"}"}}},{"component":{"componentType":"hongrenSearch","userName":"米C小姐","userTypeName":"美妆达人","description":"达人经验6年，2014获得腾讯时尚达人称号，瑞丽签约达人，乐峰网签约达人，太平洋女性网认证资深达人、网易女人认证达人，新浪认证达人、pclady时尚博主。","userAvatar":"http://api.upload4.pimg.cn/user_upload/641e136f35964e69a65a404edb4e2856.jpeg_thumb_120x%3E_.jpeg","action":{"type":"user","actionType":"detail","id":4775388,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u8fbe\\u4eba\\u7ecf\\u9a8c6\\u5e74\\uff0c2014\\u83b7\\u5f97\\u817e\\u8baf\\u65f6\\u5c1a\\u8fbe\\u4eba\\u79f0\\u53f7\\uff0c\\u745e\\u4e3d\\u7b7e\\u7ea6\\u8fbe\\u4eba\\uff0c\\u4e50\\u5cf0\\u7f51\\u7b7e\\u7ea6\\u8fbe\\u4eba\\uff0c\\u592a\\u5e73\\u6d0b\\u5973\\u6027\\u7f51\\u8ba4\\u8bc1\\u8d44\\u6df1\\u8fbe\\u4eba\\u3001\\u7f51\\u6613\\u5973\\u4eba\\u8ba4\\u8bc1\\u8fbe\\u4eba\\uff0c\\u65b0\\u6d6a\\u8ba4\\u8bc1\\u8fbe\\u4eba\\u3001pclady\\u65f6\\u5c1a\\u535a\\u4e3b\\u3002\",\"fans_count\":0,\"name\":\"\\u7c73C\\u5c0f\\u59d0\",\"avatar_img_id\":959132,\"id\":4775388,\"avatar\":\"http:\\/\\/qzapp.qlogo.cn\\/qzapp\\/100276062\\/BB9FF4FA6E51339903CAE1AD9BC19749\\/100\",\"type\":\"\\u7f8e\\u5986\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:15.484052\"}"}}}],"appApi":"/search/query"}
     */

    private String message;
    private DataBean data;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * items : [{"component":{"componentType":"hongrenSearch","userName":"minilady","userTypeName":"穿搭达人","description":"在韩国学习生活7年，酷爱韩国的时尚文化，耳濡目染的同时自己对韩国的时尚文化有独特的见解，希望把自己平时看到的和听到的好东西传递给明星衣橱的MM们，传递美美的正能量。","userAvatar":"http://api.upload3.pimg.cn/user_upload/b8a77c00f6b14e9896cd61861985a62c.jpeg_thumb_120x%3E_.jpeg","action":{"type":"user","actionType":"detail","id":1169728,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u5728\\u97e9\\u56fd\\u5b66\\u4e60\\u751f\\u6d3b7\\u5e74\\uff0c\\u9177\\u7231\\u97e9\\u56fd\\u7684\\u65f6\\u5c1a\\u6587\\u5316\\uff0c\\u8033\\u6fe1\\u76ee\\u67d3\\u7684\\u540c\\u65f6\\u81ea\\u5df1\\u5bf9\\u97e9\\u56fd\\u7684\\u65f6\\u5c1a\\u6587\\u5316\\u6709\\u72ec\\u7279\\u7684\\u89c1\\u89e3\\uff0c\\u5e0c\\u671b\\u628a\\u81ea\\u5df1\\u5e73\\u65f6\\u770b\\u5230\\u7684\\u548c\\u542c\\u5230\\u7684\\u597d\\u4e1c\\u897f\\u4f20\\u9012\\u7ed9\\u660e\\u661f\\u8863\\u6a71\\u7684MM\\u4eec\\uff0c\\u4f20\\u9012\\u7f8e\\u7f8e\\u7684\\u6b63\\u80fd\\u91cf\\u3002\",\"fans_count\":3,\"name\":\"minilady\",\"avatar_img_id\":2237462,\"id\":1169728,\"avatar\":\"http:\\/\\/tp3.sinaimg.cn\\/1663448522\\/180\\/40012377904\\/0\",\"type\":\"\\u7a7f\\u642d\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:13.091385\"}"}}},{"component":{"componentType":"hongrenSearch","userName":"a布","userTypeName":"乐活达人","description":"时尚店主","userAvatar":"http://mxycforum.u.qiniudn.com/2014-09-17-61c61d02d00a0f0642cb17171dc48854","action":{"type":"user","actionType":"detail","id":326808,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u65f6\\u5c1a\\u5e97\\u4e3b\",\"fans_count\":2,\"name\":\"a\\u5e03\",\"avatar_img_id\":338920,\"id\":326808,\"avatar\":\"http:\\/\\/qzapp.qlogo.cn\\/qzapp\\/100276062\\/A29357CD22303383D73A620835FE155B\\/100\",\"type\":\"\\u4e50\\u6d3b\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:06.743357\"}"}}},{"component":{"componentType":"hongrenSearch","userName":"miss曼a_a","userTypeName":"穿搭达人","description":"人气时尚博主，时尚撰稿人","userAvatar":"http://tp3.sinaimg.cn/2272814962/180/40053713207/0","action":{"type":"user","actionType":"detail","id":1761455,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u4eba\\u6c14\\u65f6\\u5c1a\\u535a\\u4e3b\\uff0c\\u65f6\\u5c1a\\u64b0\\u7a3f\\u4eba\",\"fans_count\":2,\"name\":\"miss\\u66fca_a\",\"avatar_img_id\":0,\"id\":1761455,\"avatar\":\"http:\\/\\/tp3.sinaimg.cn\\/2272814962\\/180\\/40053713207\\/0\",\"type\":\"\\u7a7f\\u642d\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:07.372844\"}"}}},{"component":{"componentType":"hongrenSearch","userName":"A Super XIN","userTypeName":"乐活达人","description":"时尚店主","userAvatar":"http://api.upload1.pimg.cn/user_upload/ffab7bddcb4d459791cde2b9330fbfa5.jpeg_thumb_120x%3E_.jpeg","action":{"type":"user","actionType":"detail","id":958111,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u65f6\\u5c1a\\u5e97\\u4e3b\",\"fans_count\":2,\"name\":\"A Super XIN\",\"avatar_img_id\":1449870,\"id\":958111,\"avatar\":\"http:\\/\\/tp3.sinaimg.cn\\/2242238730\\/180\\/5688898172\\/0\",\"type\":\"\\u4e50\\u6d3b\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:07.667867\"}"}}},{"component":{"componentType":"hongrenSearch","userName":"安缇娜A-tina","userTypeName":"穿搭达人","description":"即是朋友眼中的穿搭达人，又是一名时尚店主，还是一位在校生哦！","userAvatar":"http://api.upload2.pimg.cn/user_upload/d062e70be5e74d4684c5be1855df4850.jpeg_thumb_120x%3E_.jpeg","action":{"type":"user","actionType":"detail","id":4504999,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u5373\\u662f\\u670b\\u53cb\\u773c\\u4e2d\\u7684\\u7a7f\\u642d\\u8fbe\\u4eba\\uff0c\\u53c8\\u662f\\u4e00\\u540d\\u65f6\\u5c1a\\u5e97\\u4e3b\\uff0c\\u8fd8\\u662f\\u4e00\\u4f4d\\u5728\\u6821\\u751f\\u54e6\\uff01\",\"fans_count\":0,\"name\":\"\\u5b89\\u7f07\\u5a1cA-tina\",\"avatar_img_id\":917584,\"id\":4504999,\"avatar\":\"\",\"type\":\"\\u7a7f\\u642d\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:13.872323\"}"}}},{"component":{"componentType":"hongrenSearch","userName":"米C小姐","userTypeName":"美妆达人","description":"达人经验6年，2014获得腾讯时尚达人称号，瑞丽签约达人，乐峰网签约达人，太平洋女性网认证资深达人、网易女人认证达人，新浪认证达人、pclady时尚博主。","userAvatar":"http://api.upload4.pimg.cn/user_upload/641e136f35964e69a65a404edb4e2856.jpeg_thumb_120x%3E_.jpeg","action":{"type":"user","actionType":"detail","id":4775388,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u8fbe\\u4eba\\u7ecf\\u9a8c6\\u5e74\\uff0c2014\\u83b7\\u5f97\\u817e\\u8baf\\u65f6\\u5c1a\\u8fbe\\u4eba\\u79f0\\u53f7\\uff0c\\u745e\\u4e3d\\u7b7e\\u7ea6\\u8fbe\\u4eba\\uff0c\\u4e50\\u5cf0\\u7f51\\u7b7e\\u7ea6\\u8fbe\\u4eba\\uff0c\\u592a\\u5e73\\u6d0b\\u5973\\u6027\\u7f51\\u8ba4\\u8bc1\\u8d44\\u6df1\\u8fbe\\u4eba\\u3001\\u7f51\\u6613\\u5973\\u4eba\\u8ba4\\u8bc1\\u8fbe\\u4eba\\uff0c\\u65b0\\u6d6a\\u8ba4\\u8bc1\\u8fbe\\u4eba\\u3001pclady\\u65f6\\u5c1a\\u535a\\u4e3b\\u3002\",\"fans_count\":0,\"name\":\"\\u7c73C\\u5c0f\\u59d0\",\"avatar_img_id\":959132,\"id\":4775388,\"avatar\":\"http:\\/\\/qzapp.qlogo.cn\\/qzapp\\/100276062\\/BB9FF4FA6E51339903CAE1AD9BC19749\\/100\",\"type\":\"\\u7f8e\\u5986\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:15.484052\"}"}}}]
         * appApi : /search/query
         */

        private String appApi;
        private List<ItemsBean> items;

        public String getAppApi() {
            return appApi;
        }

        public void setAppApi(String appApi) {
            this.appApi = appApi;
        }

        public List<ItemsBean> getItems() {
            return items;
        }

        public void setItems(List<ItemsBean> items) {
            this.items = items;
        }

        public static class ItemsBean {
            /**
             * component : {"componentType":"hongrenSearch","userName":"minilady","userTypeName":"穿搭达人","description":"在韩国学习生活7年，酷爱韩国的时尚文化，耳濡目染的同时自己对韩国的时尚文化有独特的见解，希望把自己平时看到的和听到的好东西传递给明星衣橱的MM们，传递美美的正能量。","userAvatar":"http://api.upload3.pimg.cn/user_upload/b8a77c00f6b14e9896cd61861985a62c.jpeg_thumb_120x%3E_.jpeg","action":{"type":"user","actionType":"detail","id":1169728,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u5728\\u97e9\\u56fd\\u5b66\\u4e60\\u751f\\u6d3b7\\u5e74\\uff0c\\u9177\\u7231\\u97e9\\u56fd\\u7684\\u65f6\\u5c1a\\u6587\\u5316\\uff0c\\u8033\\u6fe1\\u76ee\\u67d3\\u7684\\u540c\\u65f6\\u81ea\\u5df1\\u5bf9\\u97e9\\u56fd\\u7684\\u65f6\\u5c1a\\u6587\\u5316\\u6709\\u72ec\\u7279\\u7684\\u89c1\\u89e3\\uff0c\\u5e0c\\u671b\\u628a\\u81ea\\u5df1\\u5e73\\u65f6\\u770b\\u5230\\u7684\\u548c\\u542c\\u5230\\u7684\\u597d\\u4e1c\\u897f\\u4f20\\u9012\\u7ed9\\u660e\\u661f\\u8863\\u6a71\\u7684MM\\u4eec\\uff0c\\u4f20\\u9012\\u7f8e\\u7f8e\\u7684\\u6b63\\u80fd\\u91cf\\u3002\",\"fans_count\":3,\"name\":\"minilady\",\"avatar_img_id\":2237462,\"id\":1169728,\"avatar\":\"http:\\/\\/tp3.sinaimg.cn\\/1663448522\\/180\\/40012377904\\/0\",\"type\":\"\\u7a7f\\u642d\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:13.091385\"}"}}
             */

            private ComponentBean component;

            public ComponentBean getComponent() {
                return component;
            }

            public void setComponent(ComponentBean component) {
                this.component = component;
            }

            public static class ComponentBean {
                /**
                 * componentType : hongrenSearch
                 * userName : minilady
                 * userTypeName : 穿搭达人
                 * description : 在韩国学习生活7年，酷爱韩国的时尚文化，耳濡目染的同时自己对韩国的时尚文化有独特的见解，希望把自己平时看到的和听到的好东西传递给明星衣橱的MM们，传递美美的正能量。
                 * userAvatar : http://api.upload3.pimg.cn/user_upload/b8a77c00f6b14e9896cd61861985a62c.jpeg_thumb_120x%3E_.jpeg
                 * action : {"type":"user","actionType":"detail","id":1169728,"trackQuery":"query;;a;;hongren;;{\"user_desc\":\"\\u5728\\u97e9\\u56fd\\u5b66\\u4e60\\u751f\\u6d3b7\\u5e74\\uff0c\\u9177\\u7231\\u97e9\\u56fd\\u7684\\u65f6\\u5c1a\\u6587\\u5316\\uff0c\\u8033\\u6fe1\\u76ee\\u67d3\\u7684\\u540c\\u65f6\\u81ea\\u5df1\\u5bf9\\u97e9\\u56fd\\u7684\\u65f6\\u5c1a\\u6587\\u5316\\u6709\\u72ec\\u7279\\u7684\\u89c1\\u89e3\\uff0c\\u5e0c\\u671b\\u628a\\u81ea\\u5df1\\u5e73\\u65f6\\u770b\\u5230\\u7684\\u548c\\u542c\\u5230\\u7684\\u597d\\u4e1c\\u897f\\u4f20\\u9012\\u7ed9\\u660e\\u661f\\u8863\\u6a71\\u7684MM\\u4eec\\uff0c\\u4f20\\u9012\\u7f8e\\u7f8e\\u7684\\u6b63\\u80fd\\u91cf\\u3002\",\"fans_count\":3,\"name\":\"minilady\",\"avatar_img_id\":2237462,\"id\":1169728,\"avatar\":\"http:\\/\\/tp3.sinaimg.cn\\/1663448522\\/180\\/40012377904\\/0\",\"type\":\"\\u7a7f\\u642d\\u8fbe\\u4eba\",\"publish_date\":\"2016-07-11T15:15:13.091385\"}"}
                 */

                private String componentType;
                private String userName;
                private String userTypeName;
                private String description;
                private String userAvatar;
                private ActionBean action;

                public String getComponentType() {
                    return componentType;
                }

                public void setComponentType(String componentType) {
                    this.componentType = componentType;
                }

                public String getUserName() {
                    return userName;
                }

                public void setUserName(String userName) {
                    this.userName = userName;
                }

                public String getUserTypeName() {
                    return userTypeName;
                }

                public void setUserTypeName(String userTypeName) {
                    this.userTypeName = userTypeName;
                }

                public String getDescription() {
                    return description;
                }

                public void setDescription(String description) {
                    this.description = description;
                }

                public String getUserAvatar() {
                    return userAvatar;
                }

                public void setUserAvatar(String userAvatar) {
                    this.userAvatar = userAvatar;
                }

                public ActionBean getAction() {
                    return action;
                }

                public void setAction(ActionBean action) {
                    this.action = action;
                }

                public static class ActionBean {
                    /**
                     * type : user
                     * actionType : detail
                     * id : 1169728
                     * trackQuery : query;;a;;hongren;;{"user_desc":"\u5728\u97e9\u56fd\u5b66\u4e60\u751f\u6d3b7\u5e74\uff0c\u9177\u7231\u97e9\u56fd\u7684\u65f6\u5c1a\u6587\u5316\uff0c\u8033\u6fe1\u76ee\u67d3\u7684\u540c\u65f6\u81ea\u5df1\u5bf9\u97e9\u56fd\u7684\u65f6\u5c1a\u6587\u5316\u6709\u72ec\u7279\u7684\u89c1\u89e3\uff0c\u5e0c\u671b\u628a\u81ea\u5df1\u5e73\u65f6\u770b\u5230\u7684\u548c\u542c\u5230\u7684\u597d\u4e1c\u897f\u4f20\u9012\u7ed9\u660e\u661f\u8863\u6a71\u7684MM\u4eec\uff0c\u4f20\u9012\u7f8e\u7f8e\u7684\u6b63\u80fd\u91cf\u3002","fans_count":3,"name":"minilady","avatar_img_id":2237462,"id":1169728,"avatar":"http:\/\/tp3.sinaimg.cn\/1663448522\/180\/40012377904\/0","type":"\u7a7f\u642d\u8fbe\u4eba","publish_date":"2016-07-11T15:15:13.091385"}
                     */

                    private String type;
                    private String actionType;
                    private int id;
                    private String trackQuery;

                    public String getType() {
                        return type;
                    }

                    public void setType(String type) {
                        this.type = type;
                    }

                    public String getActionType() {
                        return actionType;
                    }

                    public void setActionType(String actionType) {
                        this.actionType = actionType;
                    }

                    public int getId() {
                        return id;
                    }

                    public void setId(int id) {
                        this.id = id;
                    }

                    public String getTrackQuery() {
                        return trackQuery;
                    }

                    public void setTrackQuery(String trackQuery) {
                        this.trackQuery = trackQuery;
                    }
                }
            }
        }
    }
}
