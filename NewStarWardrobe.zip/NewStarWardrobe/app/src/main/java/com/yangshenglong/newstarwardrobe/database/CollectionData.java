package com.yangshenglong.newstarwardrobe.database;

/**
 * Created by CST on 16/12/29.
 * 收藏
 */

public class CollectionData {
}
