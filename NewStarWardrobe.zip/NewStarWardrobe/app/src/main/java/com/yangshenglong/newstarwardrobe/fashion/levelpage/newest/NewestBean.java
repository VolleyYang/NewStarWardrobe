package com.yangshenglong.newstarwardrobe.fashion.levelpage.newest;

import java.util.List;

/**
 * Created by VolleyYang on 16/12/21.
 */

public class NewestBean {


    /**
     * response : {"code":0,"msg":"","isNew":1,"version":"","data":{"items":[{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"刚刚","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495100","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/15/wKgBjVhaax-AOBgIAAVkBxArb5Y38.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495100","banner_id":"495100"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"刚刚","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://s3.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495099","pics":"http://s3.mingxingyichu.cn/group6/M00/9E/0A/wKgBjFhaaxKAdD8ZAALB-72FWjI20.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495099","banner_id":"495099"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"刚刚","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://s5.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495098","pics":"http://s0.mingxingyichu.cn/group6/M00/9E/15/wKgBjVhaaweARFUVAAaUyXjpi5s13.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495098","banner_id":"495098"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"8分钟前","user":{"action":{"actionType":"detail","type":"user","id":"98"},"userAvatar":"http://m5.mingxingyichu.cn/images/images/20130526/bd8d2617-6559-4769-9a2f-b5a370836df7.jpg?imageMogr2/format/WEBP","userId":"98","username":"半个甜甜圈儿","datatime":"8分钟前"},"userId":"98","content":"本土达人，灰色套头毛衣+蓝色破","id":"495085","pics":"http://s6.mingxingyichu.cn/group6/M00/9D/D2/wKgBjVhSb6-APpXeABBTEwmOEaE420.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495085","banner_id":"495085"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"163"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"17分钟前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"17分钟前"},"userId":"7107711","content":"曹云金恋上嫩模\n\n编辑：呆毛曹","id":"495014","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/B9/wKgBf1haF4CAYuXjAARXP-Akd94271.jpg","action":{"actionType":"detail","type":"thread","id":"495014","banner_id":"495014"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"156"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"19分钟前","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"19分钟前"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495084","pics":"http://s3.mingxingyichu.cn/group5/M00/53/D4/wKgBfVhaZ0WAUZPHAAa6kvkUJzw61.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495084","banner_id":"495084"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"19分钟前","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"19分钟前"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495083","pics":"http://s5.mingxingyichu.cn/group5/M00/55/C2/wKgBf1haZzqALeQXAAS8DW7bjIM31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495083","banner_id":"495083"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"20分钟前","user":{"action":{"actionType":"detail","type":"user","id":"343606"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/20130126/bf2ca31e-6b89-4c98-98d5-6f646cf184ad.jpg?imageMogr2/format/WEBP","userId":"343606","username":"定春","datatime":"20分钟前"},"userId":"343606","content":"时装主编Julia Sarr-","id":"495074","pics":"http://s2.mingxingyichu.cn/group6/M00/9C/CE/wKgBjFg38k-ASMx0AAwrHkuldh8548.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495074","banner_id":"495074"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"119"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"29分钟前","user":{"action":{"actionType":"detail","type":"user","id":"24"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/35/40/10/xml_133699423448_avatar.jpg?imageMogr2/format/WEBP","userId":"24","username":"下午茶","datatime":"29分钟前"},"userId":"24","content":"英伦修身休闲外套街头风衣","id":"495073","pics":"http://s4.mingxingyichu.cn/group6/M00/9D/E2/wKgBjVhTtEGAcbFsAAu6Km2Ghx8894.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495073","banner_id":"495073"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"70"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"38分钟前","user":{"action":{"actionType":"detail","type":"user","id":"79"},"userAvatar":"http://m3.mingxingyichu.cn/images/images/20/36/17/whi_133699427751_avatar.jpg?imageMogr2/format/WEBP","userId":"79","username":"乌兰哈托","datatime":"38分钟前"},"userId":"79","content":"时尚博主Marie Myrho","id":"495072","pics":"http://s5.mingxingyichu.cn/group5/M00/54/83/wKgBf1g38hGAC92mAAarVffHQRM034.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495072","banner_id":"495072"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"138"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"47分钟前","user":{"action":{"actionType":"detail","type":"user","id":"86"},"userAvatar":"http://m0.mingxingyichu.cn/images/images/60/48/24/bue_133699427855_avatar.jpg?imageMogr2/format/WEBP","userId":"86","username":"豆子美眉","datatime":"47分钟前"},"userId":"86","content":"精品，时尚圆领配色条纹卫衣","id":"495071","pics":"http://s2.mingxingyichu.cn/group5/M00/53/67/wKgBfVhPo6GAbVSqAAWmxbO3tLk710.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495071","banner_id":"495071"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"403"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"56分钟前","user":{"action":{"actionType":"detail","type":"user","id":"55"},"userAvatar":"http://m6.mingxingyichu.cn/images/images/37/73/86/rsw_133699423567_avatar.jpg?imageMogr2/format/WEBP","userId":"55","username":"水皮儿","datatime":"56分钟前"},"userId":"55","content":"搭配展示，Max Mara白色","id":"495070","pics":"http://s1.mingxingyichu.cn/group5/M00/55/80/wKgBf1hSX7eAb7GQAAF7MBrmeJg546.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495070","banner_id":"495070"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"97"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"90"},"userAvatar":"http://m6.mingxingyichu.cn/images/images/35/94/7/wbf_133699427868_avatar.jpg?imageMogr2/format/WEBP","userId":"90","username":"kate","datatime":"1小时前"},"userId":"90","content":"精品，网纱拼接长袖假两件连衣裙","id":"495069","pics":"http://s2.mingxingyichu.cn/group5/M00/55/77/wKgBf1hSHK2AJn8BAAWZswIPBvY818.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495069","banner_id":"495069"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"290"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"76"},"userAvatar":"http://m3.mingxingyichu.cn/images/images/59/75/61/hpg_133699423642_avatar.jpg?imageMogr2/format/WEBP","userId":"76","username":"鞋子控","datatime":"1小时前"},"userId":"76","content":"张若昀，黑色毛毛短款外套+白色","id":"495068","pics":"http://s1.mingxingyichu.cn/group6/M00/9D/C2/wKgBjFhSPhCAbTWwAAx4k-sZJ1I863.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495068","banner_id":"495068"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"349"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"14"},"userAvatar":"http://m1.mingxingyichu.cn/images/images/35/60/93/hxy_133699423402_avatar.jpg?imageMogr2/format/WEBP","userId":"14","username":"韩茉","datatime":"1小时前"},"userId":"14","content":"时尚达人，黑色毛呢长款大衣+撞","id":"495067","pics":"http://s3.mingxingyichu.cn/group6/M00/9C/18/wKgBjVgpcNaAJa0IAAmIxbglDOI972.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495067","banner_id":"495067"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"156"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"8"},"userAvatar":"http://m2.mingxingyichu.cn/images/images/84/33/92/orw_133699423373_avatar.jpg?imageMogr2/format/WEBP","userId":"8","username":"清风徐来","datatime":"1小时前"},"userId":"8","content":"时尚达人，黑色毛呢大衣+白色印","id":"495066","pics":"http://s1.mingxingyichu.cn/group5/M00/54/2D/wKgBf1gyqRSAH0HpAA_ALAOoBnk167.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495066","banner_id":"495066"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"405"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"1701301"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/B6/wKgBV1QWUiCANXAkAAAgMpIuIDk300.jpg","userId":"1701301","username":"温室效应","datatime":"1小时前"},"userId":"1701301","content":"[娱乐] 她是沈佳宜也是小龙女","id":"495082","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/C2/wKgBf1haVQSAGMkUAABrfd0ZAmE104.jpg","action":{"actionType":"detail","type":"thread","id":"495082","banner_id":"495082"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"139"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"86"},"userAvatar":"http://m1.mingxingyichu.cn/images/images/60/48/24/bue_133699427855_avatar.jpg?imageMogr2/format/WEBP","userId":"86","username":"豆子美眉","datatime":"1小时前"},"userId":"86","content":"时装买手Tiffany Hsu","id":"495065","pics":"http://s1.mingxingyichu.cn/group6/M00/9C/D8/wKgBjVg38kmAEbfaAA0IJuJmxH0341.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495065","banner_id":"495065"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"268"}}],"flag":"18:495065","last_item_id":"495100","tips":""}}
     */

    private ResponseBean response;

    public ResponseBean getResponse() {
        return response;
    }

    public void setResponse(ResponseBean response) {
        this.response = response;
    }

    public static class ResponseBean {
        /**
         * code : 0
         * msg :
         * isNew : 1
         * version :
         * data : {"items":[{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"刚刚","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495100","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/15/wKgBjVhaax-AOBgIAAVkBxArb5Y38.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495100","banner_id":"495100"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"刚刚","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://s3.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495099","pics":"http://s3.mingxingyichu.cn/group6/M00/9E/0A/wKgBjFhaaxKAdD8ZAALB-72FWjI20.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495099","banner_id":"495099"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"刚刚","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://s5.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495098","pics":"http://s0.mingxingyichu.cn/group6/M00/9E/15/wKgBjVhaaweARFUVAAaUyXjpi5s13.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495098","banner_id":"495098"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"8分钟前","user":{"action":{"actionType":"detail","type":"user","id":"98"},"userAvatar":"http://m5.mingxingyichu.cn/images/images/20130526/bd8d2617-6559-4769-9a2f-b5a370836df7.jpg?imageMogr2/format/WEBP","userId":"98","username":"半个甜甜圈儿","datatime":"8分钟前"},"userId":"98","content":"本土达人，灰色套头毛衣+蓝色破","id":"495085","pics":"http://s6.mingxingyichu.cn/group6/M00/9D/D2/wKgBjVhSb6-APpXeABBTEwmOEaE420.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495085","banner_id":"495085"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"163"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"17分钟前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"17分钟前"},"userId":"7107711","content":"曹云金恋上嫩模\n\n编辑：呆毛曹","id":"495014","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/B9/wKgBf1haF4CAYuXjAARXP-Akd94271.jpg","action":{"actionType":"detail","type":"thread","id":"495014","banner_id":"495014"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"156"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"19分钟前","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"19分钟前"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495084","pics":"http://s3.mingxingyichu.cn/group5/M00/53/D4/wKgBfVhaZ0WAUZPHAAa6kvkUJzw61.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495084","banner_id":"495084"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"19分钟前","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"19分钟前"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495083","pics":"http://s5.mingxingyichu.cn/group5/M00/55/C2/wKgBf1haZzqALeQXAAS8DW7bjIM31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495083","banner_id":"495083"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"20分钟前","user":{"action":{"actionType":"detail","type":"user","id":"343606"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/20130126/bf2ca31e-6b89-4c98-98d5-6f646cf184ad.jpg?imageMogr2/format/WEBP","userId":"343606","username":"定春","datatime":"20分钟前"},"userId":"343606","content":"时装主编Julia Sarr-","id":"495074","pics":"http://s2.mingxingyichu.cn/group6/M00/9C/CE/wKgBjFg38k-ASMx0AAwrHkuldh8548.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495074","banner_id":"495074"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"119"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"29分钟前","user":{"action":{"actionType":"detail","type":"user","id":"24"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/35/40/10/xml_133699423448_avatar.jpg?imageMogr2/format/WEBP","userId":"24","username":"下午茶","datatime":"29分钟前"},"userId":"24","content":"英伦修身休闲外套街头风衣","id":"495073","pics":"http://s4.mingxingyichu.cn/group6/M00/9D/E2/wKgBjVhTtEGAcbFsAAu6Km2Ghx8894.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495073","banner_id":"495073"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"70"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"38分钟前","user":{"action":{"actionType":"detail","type":"user","id":"79"},"userAvatar":"http://m3.mingxingyichu.cn/images/images/20/36/17/whi_133699427751_avatar.jpg?imageMogr2/format/WEBP","userId":"79","username":"乌兰哈托","datatime":"38分钟前"},"userId":"79","content":"时尚博主Marie Myrho","id":"495072","pics":"http://s5.mingxingyichu.cn/group5/M00/54/83/wKgBf1g38hGAC92mAAarVffHQRM034.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495072","banner_id":"495072"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"138"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"47分钟前","user":{"action":{"actionType":"detail","type":"user","id":"86"},"userAvatar":"http://m0.mingxingyichu.cn/images/images/60/48/24/bue_133699427855_avatar.jpg?imageMogr2/format/WEBP","userId":"86","username":"豆子美眉","datatime":"47分钟前"},"userId":"86","content":"精品，时尚圆领配色条纹卫衣","id":"495071","pics":"http://s2.mingxingyichu.cn/group5/M00/53/67/wKgBfVhPo6GAbVSqAAWmxbO3tLk710.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495071","banner_id":"495071"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"403"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"56分钟前","user":{"action":{"actionType":"detail","type":"user","id":"55"},"userAvatar":"http://m6.mingxingyichu.cn/images/images/37/73/86/rsw_133699423567_avatar.jpg?imageMogr2/format/WEBP","userId":"55","username":"水皮儿","datatime":"56分钟前"},"userId":"55","content":"搭配展示，Max Mara白色","id":"495070","pics":"http://s1.mingxingyichu.cn/group5/M00/55/80/wKgBf1hSX7eAb7GQAAF7MBrmeJg546.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495070","banner_id":"495070"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"97"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"90"},"userAvatar":"http://m6.mingxingyichu.cn/images/images/35/94/7/wbf_133699427868_avatar.jpg?imageMogr2/format/WEBP","userId":"90","username":"kate","datatime":"1小时前"},"userId":"90","content":"精品，网纱拼接长袖假两件连衣裙","id":"495069","pics":"http://s2.mingxingyichu.cn/group5/M00/55/77/wKgBf1hSHK2AJn8BAAWZswIPBvY818.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495069","banner_id":"495069"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"290"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"76"},"userAvatar":"http://m3.mingxingyichu.cn/images/images/59/75/61/hpg_133699423642_avatar.jpg?imageMogr2/format/WEBP","userId":"76","username":"鞋子控","datatime":"1小时前"},"userId":"76","content":"张若昀，黑色毛毛短款外套+白色","id":"495068","pics":"http://s1.mingxingyichu.cn/group6/M00/9D/C2/wKgBjFhSPhCAbTWwAAx4k-sZJ1I863.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495068","banner_id":"495068"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"349"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"14"},"userAvatar":"http://m1.mingxingyichu.cn/images/images/35/60/93/hxy_133699423402_avatar.jpg?imageMogr2/format/WEBP","userId":"14","username":"韩茉","datatime":"1小时前"},"userId":"14","content":"时尚达人，黑色毛呢长款大衣+撞","id":"495067","pics":"http://s3.mingxingyichu.cn/group6/M00/9C/18/wKgBjVgpcNaAJa0IAAmIxbglDOI972.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495067","banner_id":"495067"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"156"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"8"},"userAvatar":"http://m2.mingxingyichu.cn/images/images/84/33/92/orw_133699423373_avatar.jpg?imageMogr2/format/WEBP","userId":"8","username":"清风徐来","datatime":"1小时前"},"userId":"8","content":"时尚达人，黑色毛呢大衣+白色印","id":"495066","pics":"http://s1.mingxingyichu.cn/group5/M00/54/2D/wKgBf1gyqRSAH0HpAA_ALAOoBnk167.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495066","banner_id":"495066"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"405"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"1701301"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/B6/wKgBV1QWUiCANXAkAAAgMpIuIDk300.jpg","userId":"1701301","username":"温室效应","datatime":"1小时前"},"userId":"1701301","content":"[娱乐] 她是沈佳宜也是小龙女","id":"495082","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/C2/wKgBf1haVQSAGMkUAABrfd0ZAmE104.jpg","action":{"actionType":"detail","type":"thread","id":"495082","banner_id":"495082"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"139"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"86"},"userAvatar":"http://m1.mingxingyichu.cn/images/images/60/48/24/bue_133699427855_avatar.jpg?imageMogr2/format/WEBP","userId":"86","username":"豆子美眉","datatime":"1小时前"},"userId":"86","content":"时装买手Tiffany Hsu","id":"495065","pics":"http://s1.mingxingyichu.cn/group6/M00/9C/D8/wKgBjVg38kmAEbfaAA0IJuJmxH0341.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495065","banner_id":"495065"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"268"}}],"flag":"18:495065","last_item_id":"495100","tips":""}
         */

        private int code;
        private String msg;
        private int isNew;
        private String version;
        private DataBean data;

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public int getIsNew() {
            return isNew;
        }

        public void setIsNew(int isNew) {
            this.isNew = isNew;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public DataBean getData() {
            return data;
        }

        public void setData(DataBean data) {
            this.data = data;
        }

        public static class DataBean {
            /**
             * items : [{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"刚刚","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495100","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/15/wKgBjVhaax-AOBgIAAVkBxArb5Y38.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495100","banner_id":"495100"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"刚刚","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://s3.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495099","pics":"http://s3.mingxingyichu.cn/group6/M00/9E/0A/wKgBjFhaaxKAdD8ZAALB-72FWjI20.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495099","banner_id":"495099"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"刚刚","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://s5.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495098","pics":"http://s0.mingxingyichu.cn/group6/M00/9E/15/wKgBjVhaaweARFUVAAaUyXjpi5s13.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495098","banner_id":"495098"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"8分钟前","user":{"action":{"actionType":"detail","type":"user","id":"98"},"userAvatar":"http://m5.mingxingyichu.cn/images/images/20130526/bd8d2617-6559-4769-9a2f-b5a370836df7.jpg?imageMogr2/format/WEBP","userId":"98","username":"半个甜甜圈儿","datatime":"8分钟前"},"userId":"98","content":"本土达人，灰色套头毛衣+蓝色破","id":"495085","pics":"http://s6.mingxingyichu.cn/group6/M00/9D/D2/wKgBjVhSb6-APpXeABBTEwmOEaE420.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495085","banner_id":"495085"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"163"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"17分钟前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"17分钟前"},"userId":"7107711","content":"曹云金恋上嫩模\n\n编辑：呆毛曹","id":"495014","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/B9/wKgBf1haF4CAYuXjAARXP-Akd94271.jpg","action":{"actionType":"detail","type":"thread","id":"495014","banner_id":"495014"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"156"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"19分钟前","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"19分钟前"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495084","pics":"http://s3.mingxingyichu.cn/group5/M00/53/D4/wKgBfVhaZ0WAUZPHAAa6kvkUJzw61.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495084","banner_id":"495084"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"19分钟前","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"19分钟前"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495083","pics":"http://s5.mingxingyichu.cn/group5/M00/55/C2/wKgBf1haZzqALeQXAAS8DW7bjIM31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495083","banner_id":"495083"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"20分钟前","user":{"action":{"actionType":"detail","type":"user","id":"343606"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/20130126/bf2ca31e-6b89-4c98-98d5-6f646cf184ad.jpg?imageMogr2/format/WEBP","userId":"343606","username":"定春","datatime":"20分钟前"},"userId":"343606","content":"时装主编Julia Sarr-","id":"495074","pics":"http://s2.mingxingyichu.cn/group6/M00/9C/CE/wKgBjFg38k-ASMx0AAwrHkuldh8548.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495074","banner_id":"495074"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"119"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"29分钟前","user":{"action":{"actionType":"detail","type":"user","id":"24"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/35/40/10/xml_133699423448_avatar.jpg?imageMogr2/format/WEBP","userId":"24","username":"下午茶","datatime":"29分钟前"},"userId":"24","content":"英伦修身休闲外套街头风衣","id":"495073","pics":"http://s4.mingxingyichu.cn/group6/M00/9D/E2/wKgBjVhTtEGAcbFsAAu6Km2Ghx8894.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495073","banner_id":"495073"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"70"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"38分钟前","user":{"action":{"actionType":"detail","type":"user","id":"79"},"userAvatar":"http://m3.mingxingyichu.cn/images/images/20/36/17/whi_133699427751_avatar.jpg?imageMogr2/format/WEBP","userId":"79","username":"乌兰哈托","datatime":"38分钟前"},"userId":"79","content":"时尚博主Marie Myrho","id":"495072","pics":"http://s5.mingxingyichu.cn/group5/M00/54/83/wKgBf1g38hGAC92mAAarVffHQRM034.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495072","banner_id":"495072"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"138"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"47分钟前","user":{"action":{"actionType":"detail","type":"user","id":"86"},"userAvatar":"http://m0.mingxingyichu.cn/images/images/60/48/24/bue_133699427855_avatar.jpg?imageMogr2/format/WEBP","userId":"86","username":"豆子美眉","datatime":"47分钟前"},"userId":"86","content":"精品，时尚圆领配色条纹卫衣","id":"495071","pics":"http://s2.mingxingyichu.cn/group5/M00/53/67/wKgBfVhPo6GAbVSqAAWmxbO3tLk710.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495071","banner_id":"495071"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"403"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"56分钟前","user":{"action":{"actionType":"detail","type":"user","id":"55"},"userAvatar":"http://m6.mingxingyichu.cn/images/images/37/73/86/rsw_133699423567_avatar.jpg?imageMogr2/format/WEBP","userId":"55","username":"水皮儿","datatime":"56分钟前"},"userId":"55","content":"搭配展示，Max Mara白色","id":"495070","pics":"http://s1.mingxingyichu.cn/group5/M00/55/80/wKgBf1hSX7eAb7GQAAF7MBrmeJg546.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495070","banner_id":"495070"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"97"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"90"},"userAvatar":"http://m6.mingxingyichu.cn/images/images/35/94/7/wbf_133699427868_avatar.jpg?imageMogr2/format/WEBP","userId":"90","username":"kate","datatime":"1小时前"},"userId":"90","content":"精品，网纱拼接长袖假两件连衣裙","id":"495069","pics":"http://s2.mingxingyichu.cn/group5/M00/55/77/wKgBf1hSHK2AJn8BAAWZswIPBvY818.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495069","banner_id":"495069"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"290"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"76"},"userAvatar":"http://m3.mingxingyichu.cn/images/images/59/75/61/hpg_133699423642_avatar.jpg?imageMogr2/format/WEBP","userId":"76","username":"鞋子控","datatime":"1小时前"},"userId":"76","content":"张若昀，黑色毛毛短款外套+白色","id":"495068","pics":"http://s1.mingxingyichu.cn/group6/M00/9D/C2/wKgBjFhSPhCAbTWwAAx4k-sZJ1I863.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495068","banner_id":"495068"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"349"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"14"},"userAvatar":"http://m1.mingxingyichu.cn/images/images/35/60/93/hxy_133699423402_avatar.jpg?imageMogr2/format/WEBP","userId":"14","username":"韩茉","datatime":"1小时前"},"userId":"14","content":"时尚达人，黑色毛呢长款大衣+撞","id":"495067","pics":"http://s3.mingxingyichu.cn/group6/M00/9C/18/wKgBjVgpcNaAJa0IAAmIxbglDOI972.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495067","banner_id":"495067"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"156"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"8"},"userAvatar":"http://m2.mingxingyichu.cn/images/images/84/33/92/orw_133699423373_avatar.jpg?imageMogr2/format/WEBP","userId":"8","username":"清风徐来","datatime":"1小时前"},"userId":"8","content":"时尚达人，黑色毛呢大衣+白色印","id":"495066","pics":"http://s1.mingxingyichu.cn/group5/M00/54/2D/wKgBf1gyqRSAH0HpAA_ALAOoBnk167.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495066","banner_id":"495066"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"405"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"1701301"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/B6/wKgBV1QWUiCANXAkAAAgMpIuIDk300.jpg","userId":"1701301","username":"温室效应","datatime":"1小时前"},"userId":"1701301","content":"[娱乐] 她是沈佳宜也是小龙女","id":"495082","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/C2/wKgBf1haVQSAGMkUAABrfd0ZAmE104.jpg","action":{"actionType":"detail","type":"thread","id":"495082","banner_id":"495082"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"139"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1小时前","user":{"action":{"actionType":"detail","type":"user","id":"86"},"userAvatar":"http://m1.mingxingyichu.cn/images/images/60/48/24/bue_133699427855_avatar.jpg?imageMogr2/format/WEBP","userId":"86","username":"豆子美眉","datatime":"1小时前"},"userId":"86","content":"时装买手Tiffany Hsu","id":"495065","pics":"http://s1.mingxingyichu.cn/group6/M00/9C/D8/wKgBjVg38kmAEbfaAA0IJuJmxH0341.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495065","banner_id":"495065"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"268"}}]
             * flag : 18:495065
             * last_item_id : 495100
             * tips :
             */

            private String flag;
            private String last_item_id;
            private String tips;
            private List<ItemsBean> items;

            public String getFlag() {
                return flag;
            }

            public void setFlag(String flag) {
                this.flag = flag;
            }

            public String getLast_item_id() {
                return last_item_id;
            }

            public void setLast_item_id(String last_item_id) {
                this.last_item_id = last_item_id;
            }

            public String getTips() {
                return tips;
            }

            public void setTips(String tips) {
                this.tips = tips;
            }

            public List<ItemsBean> getItems() {
                return items;
            }

            public void setItems(List<ItemsBean> items) {
                this.items = items;
            }

            public static class ItemsBean {
                /**
                 * width : 177
                 * height : 235
                 * component : {"componentType":"postsListCell","datatime":"刚刚","user":{"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"},"userId":"14074998","content":"戳进来！明星衣橱有惊喜~","id":"495100","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/15/wKgBjVhaax-AOBgIAAVkBxArb5Y38.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495100","banner_id":"495100"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"0"}
                 */

                private String width;
                private String height;
                private ComponentBean component;

                public String getWidth() {
                    return width;
                }

                public void setWidth(String width) {
                    this.width = width;
                }

                public String getHeight() {
                    return height;
                }

                public void setHeight(String height) {
                    this.height = height;
                }

                public ComponentBean getComponent() {
                    return component;
                }

                public void setComponent(ComponentBean component) {
                    this.component = component;
                }

                public static class ComponentBean {
                    /**
                     * componentType : postsListCell
                     * datatime : 刚刚
                     * user : {"action":{"actionType":"detail","type":"user","id":"14074998"},"userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"14074998","username":"Chelsea","datatime":"刚刚"}
                     * userId : 14074998
                     * content : 戳进来！明星衣橱有惊喜~
                     * id : 495100
                     * pics : http://mxycsku.mingxingyichu.cn/group6/M00/9E/15/wKgBjVhaax-AOBgIAAVkBxArb5Y38.jpeg?imageMogr2/thumbnail/600x%3E/quality/95
                     * action : {"actionType":"detail","type":"thread","id":"495100","banner_id":"495100"}
                     * is_live : 0
                     * live_status : 0
                     * live_view_count : 0
                     * is_collect : 0
                     * collect_count : 0
                     */

                    private String componentType;
                    private String datatime;
                    private UserBean user;
                    private String userId;
                    private String content;
                    private String id;
                    private String pics;
                    private ActionBeanX action;
                    private String is_live;
                    private String live_status;
                    private String live_view_count;
                    private String is_collect;
                    private String collect_count;

                    public String getComponentType() {
                        return componentType;
                    }

                    public void setComponentType(String componentType) {
                        this.componentType = componentType;
                    }

                    public String getDatatime() {
                        return datatime;
                    }

                    public void setDatatime(String datatime) {
                        this.datatime = datatime;
                    }

                    public UserBean getUser() {
                        return user;
                    }

                    public void setUser(UserBean user) {
                        this.user = user;
                    }

                    public String getUserId() {
                        return userId;
                    }

                    public void setUserId(String userId) {
                        this.userId = userId;
                    }

                    public String getContent() {
                        return content;
                    }

                    public void setContent(String content) {
                        this.content = content;
                    }

                    public String getId() {
                        return id;
                    }

                    public void setId(String id) {
                        this.id = id;
                    }

                    public String getPics() {
                        return pics;
                    }

                    public void setPics(String pics) {
                        this.pics = pics;
                    }

                    public ActionBeanX getAction() {
                        return action;
                    }

                    public void setAction(ActionBeanX action) {
                        this.action = action;
                    }

                    public String getIs_live() {
                        return is_live;
                    }

                    public void setIs_live(String is_live) {
                        this.is_live = is_live;
                    }

                    public String getLive_status() {
                        return live_status;
                    }

                    public void setLive_status(String live_status) {
                        this.live_status = live_status;
                    }

                    public String getLive_view_count() {
                        return live_view_count;
                    }

                    public void setLive_view_count(String live_view_count) {
                        this.live_view_count = live_view_count;
                    }

                    public String getIs_collect() {
                        return is_collect;
                    }

                    public void setIs_collect(String is_collect) {
                        this.is_collect = is_collect;
                    }

                    public String getCollect_count() {
                        return collect_count;
                    }

                    public void setCollect_count(String collect_count) {
                        this.collect_count = collect_count;
                    }

                    public static class UserBean {
                        /**
                         * action : {"actionType":"detail","type":"user","id":"14074998"}
                         * userAvatar : http://mxycsku.mingxingyichu.cn/group5/M00/52/32/wKgBfVguybaAH2OcAAHs9Dn8YhE71.jpeg?imageMogr2/thumbnail/600x%3E/quality/95
                         * userId : 14074998
                         * username : Chelsea
                         * datatime : 刚刚
                         */

                        private ActionBean action;
                        private String userAvatar;
                        private String userId;
                        private String username;
                        private String datatime;

                        public ActionBean getAction() {
                            return action;
                        }

                        public void setAction(ActionBean action) {
                            this.action = action;
                        }

                        public String getUserAvatar() {
                            return userAvatar;
                        }

                        public void setUserAvatar(String userAvatar) {
                            this.userAvatar = userAvatar;
                        }

                        public String getUserId() {
                            return userId;
                        }

                        public void setUserId(String userId) {
                            this.userId = userId;
                        }

                        public String getUsername() {
                            return username;
                        }

                        public void setUsername(String username) {
                            this.username = username;
                        }

                        public String getDatatime() {
                            return datatime;
                        }

                        public void setDatatime(String datatime) {
                            this.datatime = datatime;
                        }

                        public static class ActionBean {
                            /**
                             * actionType : detail
                             * type : user
                             * id : 14074998
                             */

                            private String actionType;
                            private String type;
                            private String id;

                            public String getActionType() {
                                return actionType;
                            }

                            public void setActionType(String actionType) {
                                this.actionType = actionType;
                            }

                            public String getType() {
                                return type;
                            }

                            public void setType(String type) {
                                this.type = type;
                            }

                            public String getId() {
                                return id;
                            }

                            public void setId(String id) {
                                this.id = id;
                            }
                        }
                    }

                    public static class ActionBeanX {
                        /**
                         * actionType : detail
                         * type : thread
                         * id : 495100
                         * banner_id : 495100
                         */

                        private String actionType;
                        private String type;
                        private String id;
                        private String banner_id;

                        public String getActionType() {
                            return actionType;
                        }

                        public void setActionType(String actionType) {
                            this.actionType = actionType;
                        }

                        public String getType() {
                            return type;
                        }

                        public void setType(String type) {
                            this.type = type;
                        }

                        public String getId() {
                            return id;
                        }

                        public void setId(String id) {
                            this.id = id;
                        }

                        public String getBanner_id() {
                            return banner_id;
                        }

                        public void setBanner_id(String banner_id) {
                            this.banner_id = banner_id;
                        }
                    }
                }
            }
        }
    }
}
