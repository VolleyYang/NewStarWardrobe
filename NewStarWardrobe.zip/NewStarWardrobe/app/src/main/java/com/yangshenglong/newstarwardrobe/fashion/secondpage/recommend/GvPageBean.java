package com.yangshenglong.newstarwardrobe.fashion.secondpage.recommend;

import java.util.List;

/**
 * Created by VolleyYang on 16/12/22.
 */

public class GvPageBean {


    /**
     * response : {"code":0,"msg":"success","isNew":1,"version":"","data":{"tagHead":{"id":"173","icon":"http://s0.mingxingyichu.cn/group6/M00/2D/77/wKgBjVc1ldGAfWlnAAADxQbpTu4407.png","bg_url":"","description":"","title":"刘亦菲","threadCount":"","commentCount":""},"items":[{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1682109"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/38/wKgBV1QWLP-ATeJgAAA0hnyx6Xc025.jpg","userId":"1682109","username":"饮痛而歌。","datatime":"1天前"},"userId":"1682109","content":"[潮流] 刘亦菲出街私服惨不忍","id":"495042","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/06/wKgBjFhaL3SANA6EAAHc5ZdOt9c614.jpg","action":{"actionType":"detail","type":"thread","id":"495042","banner_id":"495042"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"3"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2周前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"2周前"},"userId":"1696891","content":"[娱乐] 被网友批没啥演技的演","id":"491828","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/54/F8/wKgBf1hGZziAJBm3AAcZxyiVVfs261.jpg","action":{"actionType":"detail","type":"thread","id":"491828","banner_id":"491828"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1939"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2周前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"2周前"},"userId":"1696891","content":"[娱乐] 谁才是五官最美的女星","id":"491614","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/54/ED/wKgBf1hFMAaAK6BSAAWToi09k7A388.jpg","action":{"actionType":"detail","type":"thread","id":"491614","banner_id":"491614"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1476"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2周前","user":{"action":{"actionType":"detail","type":"user","id":"41"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/81/63/91/ton_133699423510_avatar.jpg?imageMogr2/format/WEBP","userId":"41","username":"青青","datatime":"2周前"},"userId":"41","content":"刘亦菲，黑色v领装饰连衣裙+黑","id":"490883","pics":"http://s4.mingxingyichu.cn/group6/M00/9C/9B/wKgBjVg05ceAWp7cAAh1ULT_LeA724.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"490883","banner_id":"490883"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1162"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"3周前","user":{"action":{"actionType":"detail","type":"user","id":"1697687"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/13/wKgBWFQWSoqANGhFAAA6qiC0AHk786.jpg","userId":"1697687","username":"Princess smile","datatime":"3周前"},"userId":"1697687","content":"[娱乐] 盘点第一眼美女\n郑爽","id":"490546","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9D/00/wKgBjVg-fLiAMxSaAAaglrzVkf8826.jpg","action":{"actionType":"detail","type":"thread","id":"490546","banner_id":"490546"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2060"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"3周前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"3周前"},"userId":"1696891","content":"[娱乐] 盘点国产良心好剧\n这","id":"490354","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/F3/wKgBjVg9MWaAfbGRAAT05-FZJZo880.jpg","action":{"actionType":"detail","type":"thread","id":"490354","banner_id":"490354"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1657"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"3周前","user":{"action":{"actionType":"detail","type":"user","id":"1693994"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/7C/wKgBV1QWQ5uAPijQAAArrxWNO38865.jpg","userId":"1693994","username":"阿狸的桃子","datatime":"3周前"},"userId":"1693994","content":"[娱乐] 盘点十大最美古装公主","id":"489469","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/52/88/wKgBfVg3wFuAHKTtAACFJIwnpX0719.jpg","action":{"actionType":"detail","type":"thread","id":"489469","banner_id":"489469"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"5"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"黄晓明要给孩子取啥小名？\n\n编","id":"489086","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/54/4E/wKgBf1g1N3qAL5EGAAfaiVTU04E077.jpg","action":{"actionType":"detail","type":"thread","id":"489086","banner_id":"489086"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2261"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"刘亦菲低调的朋友圈\n\n编辑：呆","id":"487920","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/73/wKgBjVgu0Y2ABAAbAARfV0WzswM300.jpg","action":{"actionType":"detail","type":"thread","id":"487920","banner_id":"487920"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1424"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"5292307"},"userAvatar":"http://s0.mingxingyichu.cn/group5/M00/3D/41/wKgBfVe-eEWAEn7hAAH8jWWySys74.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"5292307","username":"全欣爱杰","datatime":"1个月前"},"userId":"5292307","content":"刘亦菲化身微肿黑天鹅\n\n\n编辑","id":"487577","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/F5/wKgBf1gtEreAUUAJAALTaSN-TFI693.jpg","action":{"actionType":"detail","type":"thread","id":"487577","banner_id":"487577"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1765"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"林丹被曝出轨\n\n编辑：呆毛昨儿","id":"487560","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/4A/wKgBjVgtNnuAXYTXAAawojBHqfI607.jpg","action":{"actionType":"detail","type":"thread","id":"487560","banner_id":"487560"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1472"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1683485"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C6/B9/wKgBWFQWL5aAefygAAAg1BHAke8910.jpg","userId":"1683485","username":"猫耳朵","datatime":"1个月前"},"userId":"1683485","content":"[娱乐] 他的笑永远定格在这里","id":"487097","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/D6/wKgBf1gqtzyAELRMAAYWySqVu-k421.jpg","action":{"actionType":"detail","type":"thread","id":"487097","banner_id":"487097"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1879"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1697090"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/93/wKgBV1QWSVWAfi1ZAAAqI3BoBNw364.jpg","userId":"1697090","username":"阿远","datatime":"1个月前"},"userId":"1697090","content":"[潮流] 8衣装|最美伴娘刘亦","id":"486205","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/05/wKgBjVgljh6AUceXAAFiYOyNl4o708.jpg","action":{"actionType":"detail","type":"thread","id":"486205","banner_id":"486205"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2228"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1698008"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/9B/wKgBV1QWSymAXUcQAAAWyuF5_2E165.jpg","userId":"1698008","username":"杨三好","datatime":"1个月前"},"userId":"1698008","content":"[娱乐] 有的替身长得比明星还","id":"486140","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/9A/wKgBf1glNmKAEhcZAAepOIalUEU173.jpg","action":{"actionType":"detail","type":"thread","id":"486140","banner_id":"486140"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1576"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"1个月前"},"userId":"1696891","content":"[娱乐] 他们是单亲妈妈养大的","id":"485779","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9B/97/wKgBjFgi9SaAK4K_AAWY24b5lJM703.jpg","action":{"actionType":"detail","type":"thread","id":"485779","banner_id":"485779"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2257"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1691954"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C6/E8/wKgBWFQWP6qAHZNHAABPEvoghx4148.jpg","userId":"1691954","username":"王大可","datatime":"1个月前"},"userId":"1691954","content":"[潮流] 张靓颖伴娘才是史上颜","id":"485739","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9B/8D/wKgBjFgiz4KARX9lAAHz9O-FFu4870.jpg","action":{"actionType":"detail","type":"thread","id":"485739","banner_id":"485739"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2244"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"张靓颖冯珂又遭大反转\n\n编辑：","id":"485399","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/1B/wKgBf1ghYV2AJ3V4AAS-9LGhuDE871.jpg","action":{"actionType":"detail","type":"thread","id":"485399","banner_id":"485399"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2287"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"1个月前"},"userId":"1696891","content":"[娱乐] 818长相最\"中国\"","id":"485463","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/29/wKgBf1ghiveALQjCAAZK3wKin2U147.jpg","action":{"actionType":"detail","type":"thread","id":"485463","banner_id":"485463"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1703"}}],"flag":"18"}}
     */

    private ResponseBean response;

    public ResponseBean getResponse() {
        return response;
    }

    public void setResponse(ResponseBean response) {
        this.response = response;
    }

    public static class ResponseBean {
        /**
         * code : 0
         * msg : success
         * isNew : 1
         * version :
         * data : {"tagHead":{"id":"173","icon":"http://s0.mingxingyichu.cn/group6/M00/2D/77/wKgBjVc1ldGAfWlnAAADxQbpTu4407.png","bg_url":"","description":"","title":"刘亦菲","threadCount":"","commentCount":""},"items":[{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1682109"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/38/wKgBV1QWLP-ATeJgAAA0hnyx6Xc025.jpg","userId":"1682109","username":"饮痛而歌。","datatime":"1天前"},"userId":"1682109","content":"[潮流] 刘亦菲出街私服惨不忍","id":"495042","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/06/wKgBjFhaL3SANA6EAAHc5ZdOt9c614.jpg","action":{"actionType":"detail","type":"thread","id":"495042","banner_id":"495042"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"3"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2周前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"2周前"},"userId":"1696891","content":"[娱乐] 被网友批没啥演技的演","id":"491828","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/54/F8/wKgBf1hGZziAJBm3AAcZxyiVVfs261.jpg","action":{"actionType":"detail","type":"thread","id":"491828","banner_id":"491828"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1939"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2周前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"2周前"},"userId":"1696891","content":"[娱乐] 谁才是五官最美的女星","id":"491614","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/54/ED/wKgBf1hFMAaAK6BSAAWToi09k7A388.jpg","action":{"actionType":"detail","type":"thread","id":"491614","banner_id":"491614"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1476"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2周前","user":{"action":{"actionType":"detail","type":"user","id":"41"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/81/63/91/ton_133699423510_avatar.jpg?imageMogr2/format/WEBP","userId":"41","username":"青青","datatime":"2周前"},"userId":"41","content":"刘亦菲，黑色v领装饰连衣裙+黑","id":"490883","pics":"http://s4.mingxingyichu.cn/group6/M00/9C/9B/wKgBjVg05ceAWp7cAAh1ULT_LeA724.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"490883","banner_id":"490883"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1162"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"3周前","user":{"action":{"actionType":"detail","type":"user","id":"1697687"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/13/wKgBWFQWSoqANGhFAAA6qiC0AHk786.jpg","userId":"1697687","username":"Princess smile","datatime":"3周前"},"userId":"1697687","content":"[娱乐] 盘点第一眼美女\n郑爽","id":"490546","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9D/00/wKgBjVg-fLiAMxSaAAaglrzVkf8826.jpg","action":{"actionType":"detail","type":"thread","id":"490546","banner_id":"490546"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2060"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"3周前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"3周前"},"userId":"1696891","content":"[娱乐] 盘点国产良心好剧\n这","id":"490354","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/F3/wKgBjVg9MWaAfbGRAAT05-FZJZo880.jpg","action":{"actionType":"detail","type":"thread","id":"490354","banner_id":"490354"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1657"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"3周前","user":{"action":{"actionType":"detail","type":"user","id":"1693994"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/7C/wKgBV1QWQ5uAPijQAAArrxWNO38865.jpg","userId":"1693994","username":"阿狸的桃子","datatime":"3周前"},"userId":"1693994","content":"[娱乐] 盘点十大最美古装公主","id":"489469","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/52/88/wKgBfVg3wFuAHKTtAACFJIwnpX0719.jpg","action":{"actionType":"detail","type":"thread","id":"489469","banner_id":"489469"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"5"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"黄晓明要给孩子取啥小名？\n\n编","id":"489086","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/54/4E/wKgBf1g1N3qAL5EGAAfaiVTU04E077.jpg","action":{"actionType":"detail","type":"thread","id":"489086","banner_id":"489086"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2261"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"刘亦菲低调的朋友圈\n\n编辑：呆","id":"487920","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/73/wKgBjVgu0Y2ABAAbAARfV0WzswM300.jpg","action":{"actionType":"detail","type":"thread","id":"487920","banner_id":"487920"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1424"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"5292307"},"userAvatar":"http://s0.mingxingyichu.cn/group5/M00/3D/41/wKgBfVe-eEWAEn7hAAH8jWWySys74.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"5292307","username":"全欣爱杰","datatime":"1个月前"},"userId":"5292307","content":"刘亦菲化身微肿黑天鹅\n\n\n编辑","id":"487577","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/F5/wKgBf1gtEreAUUAJAALTaSN-TFI693.jpg","action":{"actionType":"detail","type":"thread","id":"487577","banner_id":"487577"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1765"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"林丹被曝出轨\n\n编辑：呆毛昨儿","id":"487560","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/4A/wKgBjVgtNnuAXYTXAAawojBHqfI607.jpg","action":{"actionType":"detail","type":"thread","id":"487560","banner_id":"487560"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1472"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1683485"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C6/B9/wKgBWFQWL5aAefygAAAg1BHAke8910.jpg","userId":"1683485","username":"猫耳朵","datatime":"1个月前"},"userId":"1683485","content":"[娱乐] 他的笑永远定格在这里","id":"487097","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/D6/wKgBf1gqtzyAELRMAAYWySqVu-k421.jpg","action":{"actionType":"detail","type":"thread","id":"487097","banner_id":"487097"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1879"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1697090"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/93/wKgBV1QWSVWAfi1ZAAAqI3BoBNw364.jpg","userId":"1697090","username":"阿远","datatime":"1个月前"},"userId":"1697090","content":"[潮流] 8衣装|最美伴娘刘亦","id":"486205","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/05/wKgBjVgljh6AUceXAAFiYOyNl4o708.jpg","action":{"actionType":"detail","type":"thread","id":"486205","banner_id":"486205"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2228"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1698008"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/9B/wKgBV1QWSymAXUcQAAAWyuF5_2E165.jpg","userId":"1698008","username":"杨三好","datatime":"1个月前"},"userId":"1698008","content":"[娱乐] 有的替身长得比明星还","id":"486140","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/9A/wKgBf1glNmKAEhcZAAepOIalUEU173.jpg","action":{"actionType":"detail","type":"thread","id":"486140","banner_id":"486140"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1576"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"1个月前"},"userId":"1696891","content":"[娱乐] 他们是单亲妈妈养大的","id":"485779","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9B/97/wKgBjFgi9SaAK4K_AAWY24b5lJM703.jpg","action":{"actionType":"detail","type":"thread","id":"485779","banner_id":"485779"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2257"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1691954"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C6/E8/wKgBWFQWP6qAHZNHAABPEvoghx4148.jpg","userId":"1691954","username":"王大可","datatime":"1个月前"},"userId":"1691954","content":"[潮流] 张靓颖伴娘才是史上颜","id":"485739","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9B/8D/wKgBjFgiz4KARX9lAAHz9O-FFu4870.jpg","action":{"actionType":"detail","type":"thread","id":"485739","banner_id":"485739"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2244"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"张靓颖冯珂又遭大反转\n\n编辑：","id":"485399","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/1B/wKgBf1ghYV2AJ3V4AAS-9LGhuDE871.jpg","action":{"actionType":"detail","type":"thread","id":"485399","banner_id":"485399"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2287"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"1个月前"},"userId":"1696891","content":"[娱乐] 818长相最\"中国\"","id":"485463","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/29/wKgBf1ghiveALQjCAAZK3wKin2U147.jpg","action":{"actionType":"detail","type":"thread","id":"485463","banner_id":"485463"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1703"}}],"flag":"18"}
         */

        private int code;
        private String msg;
        private int isNew;
        private String version;
        private DataBean data;

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public int getIsNew() {
            return isNew;
        }

        public void setIsNew(int isNew) {
            this.isNew = isNew;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public DataBean getData() {
            return data;
        }

        public void setData(DataBean data) {
            this.data = data;
        }

        public static class DataBean {
            /**
             * tagHead : {"id":"173","icon":"http://s0.mingxingyichu.cn/group6/M00/2D/77/wKgBjVc1ldGAfWlnAAADxQbpTu4407.png","bg_url":"","description":"","title":"刘亦菲","threadCount":"","commentCount":""}
             * items : [{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1682109"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/38/wKgBV1QWLP-ATeJgAAA0hnyx6Xc025.jpg","userId":"1682109","username":"饮痛而歌。","datatime":"1天前"},"userId":"1682109","content":"[潮流] 刘亦菲出街私服惨不忍","id":"495042","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/06/wKgBjFhaL3SANA6EAAHc5ZdOt9c614.jpg","action":{"actionType":"detail","type":"thread","id":"495042","banner_id":"495042"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"3"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2周前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"2周前"},"userId":"1696891","content":"[娱乐] 被网友批没啥演技的演","id":"491828","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/54/F8/wKgBf1hGZziAJBm3AAcZxyiVVfs261.jpg","action":{"actionType":"detail","type":"thread","id":"491828","banner_id":"491828"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1939"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2周前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"2周前"},"userId":"1696891","content":"[娱乐] 谁才是五官最美的女星","id":"491614","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/54/ED/wKgBf1hFMAaAK6BSAAWToi09k7A388.jpg","action":{"actionType":"detail","type":"thread","id":"491614","banner_id":"491614"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1476"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2周前","user":{"action":{"actionType":"detail","type":"user","id":"41"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/81/63/91/ton_133699423510_avatar.jpg?imageMogr2/format/WEBP","userId":"41","username":"青青","datatime":"2周前"},"userId":"41","content":"刘亦菲，黑色v领装饰连衣裙+黑","id":"490883","pics":"http://s4.mingxingyichu.cn/group6/M00/9C/9B/wKgBjVg05ceAWp7cAAh1ULT_LeA724.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"490883","banner_id":"490883"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1162"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"3周前","user":{"action":{"actionType":"detail","type":"user","id":"1697687"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/13/wKgBWFQWSoqANGhFAAA6qiC0AHk786.jpg","userId":"1697687","username":"Princess smile","datatime":"3周前"},"userId":"1697687","content":"[娱乐] 盘点第一眼美女\n郑爽","id":"490546","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9D/00/wKgBjVg-fLiAMxSaAAaglrzVkf8826.jpg","action":{"actionType":"detail","type":"thread","id":"490546","banner_id":"490546"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2060"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"3周前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"3周前"},"userId":"1696891","content":"[娱乐] 盘点国产良心好剧\n这","id":"490354","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/F3/wKgBjVg9MWaAfbGRAAT05-FZJZo880.jpg","action":{"actionType":"detail","type":"thread","id":"490354","banner_id":"490354"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1657"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"3周前","user":{"action":{"actionType":"detail","type":"user","id":"1693994"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/7C/wKgBV1QWQ5uAPijQAAArrxWNO38865.jpg","userId":"1693994","username":"阿狸的桃子","datatime":"3周前"},"userId":"1693994","content":"[娱乐] 盘点十大最美古装公主","id":"489469","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/52/88/wKgBfVg3wFuAHKTtAACFJIwnpX0719.jpg","action":{"actionType":"detail","type":"thread","id":"489469","banner_id":"489469"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"5"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"黄晓明要给孩子取啥小名？\n\n编","id":"489086","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/54/4E/wKgBf1g1N3qAL5EGAAfaiVTU04E077.jpg","action":{"actionType":"detail","type":"thread","id":"489086","banner_id":"489086"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2261"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"刘亦菲低调的朋友圈\n\n编辑：呆","id":"487920","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/73/wKgBjVgu0Y2ABAAbAARfV0WzswM300.jpg","action":{"actionType":"detail","type":"thread","id":"487920","banner_id":"487920"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1424"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"5292307"},"userAvatar":"http://s0.mingxingyichu.cn/group5/M00/3D/41/wKgBfVe-eEWAEn7hAAH8jWWySys74.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","userId":"5292307","username":"全欣爱杰","datatime":"1个月前"},"userId":"5292307","content":"刘亦菲化身微肿黑天鹅\n\n\n编辑","id":"487577","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/F5/wKgBf1gtEreAUUAJAALTaSN-TFI693.jpg","action":{"actionType":"detail","type":"thread","id":"487577","banner_id":"487577"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1765"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"林丹被曝出轨\n\n编辑：呆毛昨儿","id":"487560","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/4A/wKgBjVgtNnuAXYTXAAawojBHqfI607.jpg","action":{"actionType":"detail","type":"thread","id":"487560","banner_id":"487560"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1472"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1683485"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C6/B9/wKgBWFQWL5aAefygAAAg1BHAke8910.jpg","userId":"1683485","username":"猫耳朵","datatime":"1个月前"},"userId":"1683485","content":"[娱乐] 他的笑永远定格在这里","id":"487097","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/D6/wKgBf1gqtzyAELRMAAYWySqVu-k421.jpg","action":{"actionType":"detail","type":"thread","id":"487097","banner_id":"487097"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1879"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1697090"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/93/wKgBV1QWSVWAfi1ZAAAqI3BoBNw364.jpg","userId":"1697090","username":"阿远","datatime":"1个月前"},"userId":"1697090","content":"[潮流] 8衣装|最美伴娘刘亦","id":"486205","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9C/05/wKgBjVgljh6AUceXAAFiYOyNl4o708.jpg","action":{"actionType":"detail","type":"thread","id":"486205","banner_id":"486205"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2228"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1698008"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/9B/wKgBV1QWSymAXUcQAAAWyuF5_2E165.jpg","userId":"1698008","username":"杨三好","datatime":"1个月前"},"userId":"1698008","content":"[娱乐] 有的替身长得比明星还","id":"486140","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/9A/wKgBf1glNmKAEhcZAAepOIalUEU173.jpg","action":{"actionType":"detail","type":"thread","id":"486140","banner_id":"486140"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1576"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"1个月前"},"userId":"1696891","content":"[娱乐] 他们是单亲妈妈养大的","id":"485779","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9B/97/wKgBjFgi9SaAK4K_AAWY24b5lJM703.jpg","action":{"actionType":"detail","type":"thread","id":"485779","banner_id":"485779"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2257"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1691954"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C6/E8/wKgBWFQWP6qAHZNHAABPEvoghx4148.jpg","userId":"1691954","username":"王大可","datatime":"1个月前"},"userId":"1691954","content":"[潮流] 张靓颖伴娘才是史上颜","id":"485739","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9B/8D/wKgBjFgiz4KARX9lAAHz9O-FFu4870.jpg","action":{"actionType":"detail","type":"thread","id":"485739","banner_id":"485739"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2244"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"1个月前"},"userId":"7107711","content":"张靓颖冯珂又遭大反转\n\n编辑：","id":"485399","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/1B/wKgBf1ghYV2AJ3V4AAS-9LGhuDE871.jpg","action":{"actionType":"detail","type":"thread","id":"485399","banner_id":"485399"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"2287"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1个月前","user":{"action":{"actionType":"detail","type":"user","id":"1696891"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/0D/wKgBWFQWSQSAJZYTAAArk_B0Yz4880.jpg","userId":"1696891","username":"狐狸雨","datatime":"1个月前"},"userId":"1696891","content":"[娱乐] 818长相最\"中国\"","id":"485463","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/29/wKgBf1ghiveALQjCAAZK3wKin2U147.jpg","action":{"actionType":"detail","type":"thread","id":"485463","banner_id":"485463"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"1703"}}]
             * flag : 18
             */

            private TagHeadBean tagHead;
            private String flag;
            private List<ItemsBean> items;

            public TagHeadBean getTagHead() {
                return tagHead;
            }

            public void setTagHead(TagHeadBean tagHead) {
                this.tagHead = tagHead;
            }

            public String getFlag() {
                return flag;
            }

            public void setFlag(String flag) {
                this.flag = flag;
            }

            public List<ItemsBean> getItems() {
                return items;
            }

            public void setItems(List<ItemsBean> items) {
                this.items = items;
            }

            public static class TagHeadBean {
                /**
                 * id : 173
                 * icon : http://s0.mingxingyichu.cn/group6/M00/2D/77/wKgBjVc1ldGAfWlnAAADxQbpTu4407.png
                 * bg_url :
                 * description :
                 * title : 刘亦菲
                 * threadCount :
                 * commentCount :
                 */

                private String id;
                private String icon;
                private String bg_url;
                private String description;
                private String title;
                private String threadCount;
                private String commentCount;

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }

                public String getIcon() {
                    return icon;
                }

                public void setIcon(String icon) {
                    this.icon = icon;
                }

                public String getBg_url() {
                    return bg_url;
                }

                public void setBg_url(String bg_url) {
                    this.bg_url = bg_url;
                }

                public String getDescription() {
                    return description;
                }

                public void setDescription(String description) {
                    this.description = description;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getThreadCount() {
                    return threadCount;
                }

                public void setThreadCount(String threadCount) {
                    this.threadCount = threadCount;
                }

                public String getCommentCount() {
                    return commentCount;
                }

                public void setCommentCount(String commentCount) {
                    this.commentCount = commentCount;
                }
            }

            public static class ItemsBean {
                /**
                 * width : 177
                 * height : 235
                 * component : {"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1682109"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/38/wKgBV1QWLP-ATeJgAAA0hnyx6Xc025.jpg","userId":"1682109","username":"饮痛而歌。","datatime":"1天前"},"userId":"1682109","content":"[潮流] 刘亦菲出街私服惨不忍","id":"495042","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/06/wKgBjFhaL3SANA6EAAHc5ZdOt9c614.jpg","action":{"actionType":"detail","type":"thread","id":"495042","banner_id":"495042"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"3"}
                 */

                private String width;
                private String height;
                private ComponentBean component;

                public String getWidth() {
                    return width;
                }

                public void setWidth(String width) {
                    this.width = width;
                }

                public String getHeight() {
                    return height;
                }

                public void setHeight(String height) {
                    this.height = height;
                }

                public ComponentBean getComponent() {
                    return component;
                }

                public void setComponent(ComponentBean component) {
                    this.component = component;
                }

                public static class ComponentBean {
                    /**
                     * componentType : postsListCell
                     * datatime : 1天前
                     * user : {"action":{"actionType":"detail","type":"user","id":"1682109"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/38/wKgBV1QWLP-ATeJgAAA0hnyx6Xc025.jpg","userId":"1682109","username":"饮痛而歌。","datatime":"1天前"}
                     * userId : 1682109
                     * content : [潮流] 刘亦菲出街私服惨不忍
                     * id : 495042
                     * pics : http://mxycsku.mingxingyichu.cn/group6/M00/9E/06/wKgBjFhaL3SANA6EAAHc5ZdOt9c614.jpg
                     * action : {"actionType":"detail","type":"thread","id":"495042","banner_id":"495042"}
                     * is_live : 0
                     * live_status : 0
                     * live_view_count : 0
                     * is_collect : 0
                     * collect_count : 3
                     */

                    private String componentType;
                    private String datatime;
                    private UserBean user;
                    private String userId;
                    private String content;
                    private String id;
                    private String pics;
                    private ActionBeanX action;
                    private String is_live;
                    private String live_status;
                    private String live_view_count;
                    private String is_collect;
                    private String collect_count;

                    public String getComponentType() {
                        return componentType;
                    }

                    public void setComponentType(String componentType) {
                        this.componentType = componentType;
                    }

                    public String getDatatime() {
                        return datatime;
                    }

                    public void setDatatime(String datatime) {
                        this.datatime = datatime;
                    }

                    public UserBean getUser() {
                        return user;
                    }

                    public void setUser(UserBean user) {
                        this.user = user;
                    }

                    public String getUserId() {
                        return userId;
                    }

                    public void setUserId(String userId) {
                        this.userId = userId;
                    }

                    public String getContent() {
                        return content;
                    }

                    public void setContent(String content) {
                        this.content = content;
                    }

                    public String getId() {
                        return id;
                    }

                    public void setId(String id) {
                        this.id = id;
                    }

                    public String getPics() {
                        return pics;
                    }

                    public void setPics(String pics) {
                        this.pics = pics;
                    }

                    public ActionBeanX getAction() {
                        return action;
                    }

                    public void setAction(ActionBeanX action) {
                        this.action = action;
                    }

                    public String getIs_live() {
                        return is_live;
                    }

                    public void setIs_live(String is_live) {
                        this.is_live = is_live;
                    }

                    public String getLive_status() {
                        return live_status;
                    }

                    public void setLive_status(String live_status) {
                        this.live_status = live_status;
                    }

                    public String getLive_view_count() {
                        return live_view_count;
                    }

                    public void setLive_view_count(String live_view_count) {
                        this.live_view_count = live_view_count;
                    }

                    public String getIs_collect() {
                        return is_collect;
                    }

                    public void setIs_collect(String is_collect) {
                        this.is_collect = is_collect;
                    }

                    public String getCollect_count() {
                        return collect_count;
                    }

                    public void setCollect_count(String collect_count) {
                        this.collect_count = collect_count;
                    }

                    public static class UserBean {
                        /**
                         * action : {"actionType":"detail","type":"user","id":"1682109"}
                         * userAvatar : http://mxycsku.qiniudn.com/group1/M00/C9/38/wKgBV1QWLP-ATeJgAAA0hnyx6Xc025.jpg
                         * userId : 1682109
                         * username : 饮痛而歌。
                         * datatime : 1天前
                         */

                        private ActionBean action;
                        private String userAvatar;
                        private String userId;
                        private String username;
                        private String datatime;

                        public ActionBean getAction() {
                            return action;
                        }

                        public void setAction(ActionBean action) {
                            this.action = action;
                        }

                        public String getUserAvatar() {
                            return userAvatar;
                        }

                        public void setUserAvatar(String userAvatar) {
                            this.userAvatar = userAvatar;
                        }

                        public String getUserId() {
                            return userId;
                        }

                        public void setUserId(String userId) {
                            this.userId = userId;
                        }

                        public String getUsername() {
                            return username;
                        }

                        public void setUsername(String username) {
                            this.username = username;
                        }

                        public String getDatatime() {
                            return datatime;
                        }

                        public void setDatatime(String datatime) {
                            this.datatime = datatime;
                        }

                        public static class ActionBean {
                            /**
                             * actionType : detail
                             * type : user
                             * id : 1682109
                             */

                            private String actionType;
                            private String type;
                            private String id;

                            public String getActionType() {
                                return actionType;
                            }

                            public void setActionType(String actionType) {
                                this.actionType = actionType;
                            }

                            public String getType() {
                                return type;
                            }

                            public void setType(String type) {
                                this.type = type;
                            }

                            public String getId() {
                                return id;
                            }

                            public void setId(String id) {
                                this.id = id;
                            }
                        }
                    }

                    public static class ActionBeanX {
                        /**
                         * actionType : detail
                         * type : thread
                         * id : 495042
                         * banner_id : 495042
                         */

                        private String actionType;
                        private String type;
                        private String id;
                        private String banner_id;

                        public String getActionType() {
                            return actionType;
                        }

                        public void setActionType(String actionType) {
                            this.actionType = actionType;
                        }

                        public String getType() {
                            return type;
                        }

                        public void setType(String type) {
                            this.type = type;
                        }

                        public String getId() {
                            return id;
                        }

                        public void setId(String id) {
                            this.id = id;
                        }

                        public String getBanner_id() {
                            return banner_id;
                        }

                        public void setBanner_id(String banner_id) {
                            this.banner_id = banner_id;
                        }
                    }
                }
            }
        }
    }
}
