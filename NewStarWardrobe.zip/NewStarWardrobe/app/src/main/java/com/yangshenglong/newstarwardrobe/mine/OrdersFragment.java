package com.yangshenglong.newstarwardrobe.mine;

import android.view.View;
import android.widget.TextView;

import com.yangshenglong.newstarwardrobe.R;
import com.yangshenglong.newstarwardrobe.base.BaseFragment;

/**
 * Created by CST on 17/1/4.
 */

public class OrdersFragment extends BaseFragment{
    private TextView tv;
    @Override
    public int setLayout() {
        return R.layout.fragment_orders;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }
}
