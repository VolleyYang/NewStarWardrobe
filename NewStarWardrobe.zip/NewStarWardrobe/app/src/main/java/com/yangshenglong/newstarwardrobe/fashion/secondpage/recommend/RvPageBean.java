package com.yangshenglong.newstarwardrobe.fashion.secondpage.recommend;

import java.util.List;

/**
 * Created by VolleyYang on 16/12/24.
 */

public class RvPageBean {


    /**
     * response : {"code":0,"msg":"success","isNew":1,"version":"","data":{"items":[{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"17小时前","user":{"action":{"actionType":"detail","type":"user","id":"70"},"userAvatar":"http://m0.mingxingyichu.cn/images/images/73/56/36/hzg_133699423622_avatar.jpg?imageMogr2/format/WEBP","userId":"70","username":"珊瑚的微笑","datatime":"17小时前"},"userId":"70","content":"范冰冰，粉色长款毛呢大衣+米色","id":"495347","pics":"http://s5.mingxingyichu.cn/group5/M00/55/8D/wKgBf1hTny2AWIQ-AASZkli2Vjs975.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495347","banner_id":"495347","track":{"eventname":"thread_about_c","cthread_id":"495347"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"463"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"21小时前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"21小时前"},"userId":"7107711","content":"编辑：呆毛突然在朋友圈就被刷屏","id":"495238","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/DC/wKgBfVhbfpWAbrsqAAT1b0_25pc168.jpg","action":{"actionType":"detail","type":"thread","id":"495238","banner_id":"495238","track":{"eventname":"thread_about_c","cthread_id":"495238"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"921"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"6小时前","user":{"action":{"actionType":"detail","type":"user","id":"1699968"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/26/wKgBWFQWT1GAajo8AABCKcgIr5Y293.jpg","userId":"1699968","username":"汤君～","datatime":"6小时前"},"userId":"1699968","content":"[娱乐] 柳岩小岳岳竟然亲上了","id":"495407","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/26/wKgBjVhciCaARj1nAADDBq2w22c346.jpg","action":{"actionType":"detail","type":"thread","id":"495407","banner_id":"495407","track":{"eventname":"thread_about_c","cthread_id":"495407"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"316"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"6小时前","user":{"action":{"actionType":"detail","type":"user","id":"1699375"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/A6/wKgBV1QWTfmAMyVWAAA_hY8yciI353.jpg","userId":"1699375","username":"玛丽不在隔壁","datatime":"6小时前"},"userId":"1699375","content":"[娱乐] 黄子韬晚上在机场晕倒","id":"495406","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/D3/wKgBf1hchpGAI6ghAACk-J5fTgs521.jpg","action":{"actionType":"detail","type":"thread","id":"495406","banner_id":"495406","track":{"eventname":"thread_about_c","cthread_id":"495406"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"551"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"7小时前","user":{"action":{"actionType":"detail","type":"user","id":"1701164"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/B5/wKgBV1QWUd6AL0h5AAAn3-lVDcs231.jpg","userId":"1701164","username":"Avril Lavigne","datatime":"7小时前"},"userId":"1701164","content":"[娱乐] 这些星二代没继承父母","id":"495270","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/18/wKgBjFhblq-AXWOGAACSmzv-k3E255.jpg","action":{"actionType":"detail","type":"thread","id":"495270","banner_id":"495270","track":{"eventname":"thread_about_c","cthread_id":"495270"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"192"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1698041"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/16/wKgBWFQWSzaAItlBAAA-g_bpOIY531.jpg","userId":"1698041","username":"雨落掌心","datatime":"1天前"},"userId":"1698041","content":"[娱乐] 杜鹃一袭长裙亮相发布","id":"495265","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/CD/wKgBf1hbjumAeUBzAABkpRVBDSw840.jpg","action":{"actionType":"detail","type":"thread","id":"495265","banner_id":"495265","track":{"eventname":"thread_about_c","cthread_id":"495265"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"667"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1685855"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/4A/wKgBV1QWNBaAbEImAAA0twvQOQ8265.jpg","userId":"1685855","username":"黄毛圈圈","datatime":"1天前"},"userId":"1685855","content":"[娱乐] 萌娃翻拍《蓝海》啦！","id":"495262","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/DE/wKgBfVhbjCOAWWrwAACbSJtZN5c007.jpg","action":{"actionType":"detail","type":"thread","id":"495262","banner_id":"495262","track":{"eventname":"thread_about_c","cthread_id":"495262"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"485"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1693897"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C6/F5/wKgBWFQWQ2qAHn8PAAAtkUMy2pA191.jpg","userId":"1693897","username":"猫小咪咪","datatime":"1天前"},"userId":"1693897","content":"[娱乐] 盘点最幸福的明星家庭","id":"495235","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/C7/wKgBf1hbbsSAS41zAAB43EfBlFQ955.jpg","action":{"actionType":"detail","type":"thread","id":"495235","banner_id":"495235","track":{"eventname":"thread_about_c","cthread_id":"495235"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"698"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1699968"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/26/wKgBWFQWT1GAajo8AABCKcgIr5Y293.jpg","userId":"1699968","username":"汤君～","datatime":"1天前"},"userId":"1699968","content":"[娱乐] 王凯陈乔恩虐狗花絮","id":"495220","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/0D/wKgBjFhbUNqAc1XlAABqWS8WdnI147.jpg","action":{"actionType":"detail","type":"thread","id":"495220","banner_id":"495220","track":{"eventname":"thread_about_c","cthread_id":"495220"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"337"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1695222"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/00/wKgBWFQWRd-AdYWeAABTRBjhRpk902.jpg","userId":"1695222","username":"山寺桃花","datatime":"1天前"},"userId":"1695222","content":"[娱乐] 徐静蕾开微信发布会","id":"495198","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/0C/wKgBjFhbQKuAbyUQAABvlHhZVsc980.jpg","action":{"actionType":"detail","type":"thread","id":"495198","banner_id":"495198","track":{"eventname":"thread_about_c","cthread_id":"495198"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"951"}}]}}
     */

    private ResponseBean response;

    public ResponseBean getResponse() {
        return response;
    }

    public void setResponse(ResponseBean response) {
        this.response = response;
    }

    public static class ResponseBean {
        /**
         * code : 0
         * msg : success
         * isNew : 1
         * version :
         * data : {"items":[{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"17小时前","user":{"action":{"actionType":"detail","type":"user","id":"70"},"userAvatar":"http://m0.mingxingyichu.cn/images/images/73/56/36/hzg_133699423622_avatar.jpg?imageMogr2/format/WEBP","userId":"70","username":"珊瑚的微笑","datatime":"17小时前"},"userId":"70","content":"范冰冰，粉色长款毛呢大衣+米色","id":"495347","pics":"http://s5.mingxingyichu.cn/group5/M00/55/8D/wKgBf1hTny2AWIQ-AASZkli2Vjs975.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495347","banner_id":"495347","track":{"eventname":"thread_about_c","cthread_id":"495347"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"463"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"21小时前","user":{"action":{"actionType":"detail","type":"user","id":"7107711"},"userAvatar":"http://tp4.sinaimg.cn/2033970603/180/22837154255/0","userId":"7107711","username":"奋斗里格楞","datatime":"21小时前"},"userId":"7107711","content":"编辑：呆毛突然在朋友圈就被刷屏","id":"495238","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/DC/wKgBfVhbfpWAbrsqAAT1b0_25pc168.jpg","action":{"actionType":"detail","type":"thread","id":"495238","banner_id":"495238","track":{"eventname":"thread_about_c","cthread_id":"495238"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"921"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"6小时前","user":{"action":{"actionType":"detail","type":"user","id":"1699968"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/26/wKgBWFQWT1GAajo8AABCKcgIr5Y293.jpg","userId":"1699968","username":"汤君～","datatime":"6小时前"},"userId":"1699968","content":"[娱乐] 柳岩小岳岳竟然亲上了","id":"495407","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/26/wKgBjVhciCaARj1nAADDBq2w22c346.jpg","action":{"actionType":"detail","type":"thread","id":"495407","banner_id":"495407","track":{"eventname":"thread_about_c","cthread_id":"495407"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"316"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"6小时前","user":{"action":{"actionType":"detail","type":"user","id":"1699375"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/A6/wKgBV1QWTfmAMyVWAAA_hY8yciI353.jpg","userId":"1699375","username":"玛丽不在隔壁","datatime":"6小时前"},"userId":"1699375","content":"[娱乐] 黄子韬晚上在机场晕倒","id":"495406","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/D3/wKgBf1hchpGAI6ghAACk-J5fTgs521.jpg","action":{"actionType":"detail","type":"thread","id":"495406","banner_id":"495406","track":{"eventname":"thread_about_c","cthread_id":"495406"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"551"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"7小时前","user":{"action":{"actionType":"detail","type":"user","id":"1701164"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/B5/wKgBV1QWUd6AL0h5AAAn3-lVDcs231.jpg","userId":"1701164","username":"Avril Lavigne","datatime":"7小时前"},"userId":"1701164","content":"[娱乐] 这些星二代没继承父母","id":"495270","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/18/wKgBjFhblq-AXWOGAACSmzv-k3E255.jpg","action":{"actionType":"detail","type":"thread","id":"495270","banner_id":"495270","track":{"eventname":"thread_about_c","cthread_id":"495270"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"192"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1698041"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/16/wKgBWFQWSzaAItlBAAA-g_bpOIY531.jpg","userId":"1698041","username":"雨落掌心","datatime":"1天前"},"userId":"1698041","content":"[娱乐] 杜鹃一袭长裙亮相发布","id":"495265","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/CD/wKgBf1hbjumAeUBzAABkpRVBDSw840.jpg","action":{"actionType":"detail","type":"thread","id":"495265","banner_id":"495265","track":{"eventname":"thread_about_c","cthread_id":"495265"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"667"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1685855"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/4A/wKgBV1QWNBaAbEImAAA0twvQOQ8265.jpg","userId":"1685855","username":"黄毛圈圈","datatime":"1天前"},"userId":"1685855","content":"[娱乐] 萌娃翻拍《蓝海》啦！","id":"495262","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/53/DE/wKgBfVhbjCOAWWrwAACbSJtZN5c007.jpg","action":{"actionType":"detail","type":"thread","id":"495262","banner_id":"495262","track":{"eventname":"thread_about_c","cthread_id":"495262"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"485"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1693897"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C6/F5/wKgBWFQWQ2qAHn8PAAAtkUMy2pA191.jpg","userId":"1693897","username":"猫小咪咪","datatime":"1天前"},"userId":"1693897","content":"[娱乐] 盘点最幸福的明星家庭","id":"495235","pics":"http://mxycsku.mingxingyichu.cn/group5/M00/55/C7/wKgBf1hbbsSAS41zAAB43EfBlFQ955.jpg","action":{"actionType":"detail","type":"thread","id":"495235","banner_id":"495235","track":{"eventname":"thread_about_c","cthread_id":"495235"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"698"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1699968"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/26/wKgBWFQWT1GAajo8AABCKcgIr5Y293.jpg","userId":"1699968","username":"汤君～","datatime":"1天前"},"userId":"1699968","content":"[娱乐] 王凯陈乔恩虐狗花絮","id":"495220","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/0D/wKgBjFhbUNqAc1XlAABqWS8WdnI147.jpg","action":{"actionType":"detail","type":"thread","id":"495220","banner_id":"495220","track":{"eventname":"thread_about_c","cthread_id":"495220"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"337"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1天前","user":{"action":{"actionType":"detail","type":"user","id":"1695222"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C7/00/wKgBWFQWRd-AdYWeAABTRBjhRpk902.jpg","userId":"1695222","username":"山寺桃花","datatime":"1天前"},"userId":"1695222","content":"[娱乐] 徐静蕾开微信发布会","id":"495198","pics":"http://mxycsku.mingxingyichu.cn/group6/M00/9E/0C/wKgBjFhbQKuAbyUQAABvlHhZVsc980.jpg","action":{"actionType":"detail","type":"thread","id":"495198","banner_id":"495198","track":{"eventname":"thread_about_c","cthread_id":"495198"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"951"}}]}
         */

        private int code;
        private String msg;
        private int isNew;
        private String version;
        private DataBean data;

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public int getIsNew() {
            return isNew;
        }

        public void setIsNew(int isNew) {
            this.isNew = isNew;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public DataBean getData() {
            return data;
        }

        public void setData(DataBean data) {
            this.data = data;
        }

        public static class DataBean {
            private List<ItemsBean> items;

            public List<ItemsBean> getItems() {
                return items;
            }

            public void setItems(List<ItemsBean> items) {
                this.items = items;
            }

            public static class ItemsBean {
                /**
                 * width : 177
                 * height : 235
                 * component : {"componentType":"postsListCell","datatime":"17小时前","user":{"action":{"actionType":"detail","type":"user","id":"70"},"userAvatar":"http://m0.mingxingyichu.cn/images/images/73/56/36/hzg_133699423622_avatar.jpg?imageMogr2/format/WEBP","userId":"70","username":"珊瑚的微笑","datatime":"17小时前"},"userId":"70","content":"范冰冰，粉色长款毛呢大衣+米色","id":"495347","pics":"http://s5.mingxingyichu.cn/group5/M00/55/8D/wKgBf1hTny2AWIQ-AASZkli2Vjs975.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"495347","banner_id":"495347","track":{"eventname":"thread_about_c","cthread_id":"495347"}},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"463"}
                 */

                private String width;
                private String height;
                private ComponentBean component;

                public String getWidth() {
                    return width;
                }

                public void setWidth(String width) {
                    this.width = width;
                }

                public String getHeight() {
                    return height;
                }

                public void setHeight(String height) {
                    this.height = height;
                }

                public ComponentBean getComponent() {
                    return component;
                }

                public void setComponent(ComponentBean component) {
                    this.component = component;
                }

                public static class ComponentBean {
                    /**
                     * componentType : postsListCell
                     * datatime : 17小时前
                     * user : {"action":{"actionType":"detail","type":"user","id":"70"},"userAvatar":"http://m0.mingxingyichu.cn/images/images/73/56/36/hzg_133699423622_avatar.jpg?imageMogr2/format/WEBP","userId":"70","username":"珊瑚的微笑","datatime":"17小时前"}
                     * userId : 70
                     * content : 范冰冰，粉色长款毛呢大衣+米色
                     * id : 495347
                     * pics : http://s5.mingxingyichu.cn/group5/M00/55/8D/wKgBf1hTny2AWIQ-AASZkli2Vjs975.jpg?imageMogr2/thumbnail/600x%3E/quality/95
                     * action : {"actionType":"detail","type":"thread","id":"495347","banner_id":"495347","track":{"eventname":"thread_about_c","cthread_id":"495347"}}
                     * is_live : 0
                     * live_status : 0
                     * live_view_count : 0
                     * is_collect : 0
                     * collect_count : 463
                     */

                    private String componentType;
                    private String datatime;
                    private UserBean user;
                    private String userId;
                    private String content;
                    private String id;
                    private String pics;
                    private ActionBeanX action;
                    private String is_live;
                    private String live_status;
                    private String live_view_count;
                    private String is_collect;
                    private String collect_count;

                    public String getComponentType() {
                        return componentType;
                    }

                    public void setComponentType(String componentType) {
                        this.componentType = componentType;
                    }

                    public String getDatatime() {
                        return datatime;
                    }

                    public void setDatatime(String datatime) {
                        this.datatime = datatime;
                    }

                    public UserBean getUser() {
                        return user;
                    }

                    public void setUser(UserBean user) {
                        this.user = user;
                    }

                    public String getUserId() {
                        return userId;
                    }

                    public void setUserId(String userId) {
                        this.userId = userId;
                    }

                    public String getContent() {
                        return content;
                    }

                    public void setContent(String content) {
                        this.content = content;
                    }

                    public String getId() {
                        return id;
                    }

                    public void setId(String id) {
                        this.id = id;
                    }

                    public String getPics() {
                        return pics;
                    }

                    public void setPics(String pics) {
                        this.pics = pics;
                    }

                    public ActionBeanX getAction() {
                        return action;
                    }

                    public void setAction(ActionBeanX action) {
                        this.action = action;
                    }

                    public String getIs_live() {
                        return is_live;
                    }

                    public void setIs_live(String is_live) {
                        this.is_live = is_live;
                    }

                    public String getLive_status() {
                        return live_status;
                    }

                    public void setLive_status(String live_status) {
                        this.live_status = live_status;
                    }

                    public String getLive_view_count() {
                        return live_view_count;
                    }

                    public void setLive_view_count(String live_view_count) {
                        this.live_view_count = live_view_count;
                    }

                    public String getIs_collect() {
                        return is_collect;
                    }

                    public void setIs_collect(String is_collect) {
                        this.is_collect = is_collect;
                    }

                    public String getCollect_count() {
                        return collect_count;
                    }

                    public void setCollect_count(String collect_count) {
                        this.collect_count = collect_count;
                    }

                    public static class UserBean {
                        /**
                         * action : {"actionType":"detail","type":"user","id":"70"}
                         * userAvatar : http://m0.mingxingyichu.cn/images/images/73/56/36/hzg_133699423622_avatar.jpg?imageMogr2/format/WEBP
                         * userId : 70
                         * username : 珊瑚的微笑
                         * datatime : 17小时前
                         */

                        private ActionBean action;
                        private String userAvatar;
                        private String userId;
                        private String username;
                        private String datatime;

                        public ActionBean getAction() {
                            return action;
                        }

                        public void setAction(ActionBean action) {
                            this.action = action;
                        }

                        public String getUserAvatar() {
                            return userAvatar;
                        }

                        public void setUserAvatar(String userAvatar) {
                            this.userAvatar = userAvatar;
                        }

                        public String getUserId() {
                            return userId;
                        }

                        public void setUserId(String userId) {
                            this.userId = userId;
                        }

                        public String getUsername() {
                            return username;
                        }

                        public void setUsername(String username) {
                            this.username = username;
                        }

                        public String getDatatime() {
                            return datatime;
                        }

                        public void setDatatime(String datatime) {
                            this.datatime = datatime;
                        }

                        public static class ActionBean {
                            /**
                             * actionType : detail
                             * type : user
                             * id : 70
                             */

                            private String actionType;
                            private String type;
                            private String id;

                            public String getActionType() {
                                return actionType;
                            }

                            public void setActionType(String actionType) {
                                this.actionType = actionType;
                            }

                            public String getType() {
                                return type;
                            }

                            public void setType(String type) {
                                this.type = type;
                            }

                            public String getId() {
                                return id;
                            }

                            public void setId(String id) {
                                this.id = id;
                            }
                        }
                    }

                    public static class ActionBeanX {
                        /**
                         * actionType : detail
                         * type : thread
                         * id : 495347
                         * banner_id : 495347
                         * track : {"eventname":"thread_about_c","cthread_id":"495347"}
                         */

                        private String actionType;
                        private String type;
                        private String id;
                        private String banner_id;
                        private TrackBean track;

                        public String getActionType() {
                            return actionType;
                        }

                        public void setActionType(String actionType) {
                            this.actionType = actionType;
                        }

                        public String getType() {
                            return type;
                        }

                        public void setType(String type) {
                            this.type = type;
                        }

                        public String getId() {
                            return id;
                        }

                        public void setId(String id) {
                            this.id = id;
                        }

                        public String getBanner_id() {
                            return banner_id;
                        }

                        public void setBanner_id(String banner_id) {
                            this.banner_id = banner_id;
                        }

                        public TrackBean getTrack() {
                            return track;
                        }

                        public void setTrack(TrackBean track) {
                            this.track = track;
                        }

                        public static class TrackBean {
                            /**
                             * eventname : thread_about_c
                             * cthread_id : 495347
                             */

                            private String eventname;
                            private String cthread_id;

                            public String getEventname() {
                                return eventname;
                            }

                            public void setEventname(String eventname) {
                                this.eventname = eventname;
                            }

                            public String getCthread_id() {
                                return cthread_id;
                            }

                            public void setCthread_id(String cthread_id) {
                                this.cthread_id = cthread_id;
                            }
                        }
                    }
                }
            }
        }
    }
}
