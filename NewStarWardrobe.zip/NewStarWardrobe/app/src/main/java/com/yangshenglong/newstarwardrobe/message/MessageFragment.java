package com.yangshenglong.newstarwardrobe.message;

import android.view.View;

import com.yangshenglong.newstarwardrobe.R;
import com.yangshenglong.newstarwardrobe.base.BaseFragment;

/**
 * Created by VolleyYang on 16/12/20.
 */

public class MessageFragment extends BaseFragment {
    @Override
    public int setLayout() {
        return R.layout.fragment_message;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }
}
