package com.yangshenglong.newstarwardrobe.shopping.third.order;

import com.yangshenglong.newstarwardrobe.base.BaseActivity;

/**
 * Created by xiaoBu on 2016/12/25.
 * 三级界面--订单确认
 */

public class OrderActivity extends BaseActivity{
    @Override
    public int setLayout() {
        return 0;
    }

    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }
}
