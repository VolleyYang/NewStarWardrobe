package com.yangshenglong.newstarwardrobe.fashion.levelpage.recommend;

/**
 * Created by VolleyYang on 16/12/2.
 */

public interface ListRvOnClick {
     void MyOnClick(int position);
}
