package com.yangshenglong.newstarwardrobe.shopping;

import android.view.View;

import com.yangshenglong.newstarwardrobe.R;
import com.yangshenglong.newstarwardrobe.base.BaseFragment;

/**
 * Created by VolleyYang on 16/12/20.
 */

public class ShopFragment extends BaseFragment {

    @Override
    public int setLayout() {
        return R.layout.fragment_shop;
    }

    @Override
    public void initView(View view) {

    }

    @Override
    public void initData() {

    }




}
