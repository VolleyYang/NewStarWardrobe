package com.yangshenglong.newstarwardrobe.database;

/**
 * Created by CST on 16/12/29.
 * 关注
 */

public class AttentionData {
}
