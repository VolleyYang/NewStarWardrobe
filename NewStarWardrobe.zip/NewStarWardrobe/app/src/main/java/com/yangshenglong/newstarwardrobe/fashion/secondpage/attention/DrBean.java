package com.yangshenglong.newstarwardrobe.fashion.secondpage.attention;

import java.util.List;

/**
 * Created by VolleyYang on 16/12/22.
 */

public class DrBean {


    /**
     * message :
     * data : {"items":[{"component":{"userName":"Burqa Ange","description":"80后全能艺人","isFollow":"0","userId":12951489,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216105"},"picUrl":"http://s0.mingxingyichu.cn/group5/M00/A2/A5/wKgBf1bc8hqAcdLxAAELyP4SdHw76.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215507"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/D4/54/wKgBjVbT7TuABTJUAAI7RQyXSAU97.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215315"},"picUrl":"http://s4.mingxingyichu.cn/group6/M00/D0/38/wKgBjFbP63qAFc7JAADyD-WEL3c27.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://wx.qlogo.cn/mmopen/DNGh0ujJaR7Nfvr11UnpD2DzkiakTCssjHrfibxKSQnTjAIfpGdNiaSb7zdUZkRBibgaWic6I5e7ibTicSlyYEARVC5Wr8aafd3Y5Mg/0","action":{"userName":"Burqa Ange","userAvatar":"http://wx.qlogo.cn/mmopen/DNGh0ujJaR7Nfvr11UnpD2DzkiakTCssjHrfibxKSQnTjAIfpGdNiaSb7zdUZkRBibgaWic6I5e7ibTicSlyYEARVC5Wr8aafd3Y5Mg/0","type":"user","id":12951489,"actionType":"detail"},"roleIcons":["http://m4.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"歌手汪苏泷","description":" 90后新生代人气偶像歌手","isFollow":"0","userId":3018604,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216270"},"picUrl":"http://s5.mingxingyichu.cn/group5/M00/A3/32/wKgBfVbeageAcIaQAAK1g_d_sJA92.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215499"},"picUrl":"http://s2.mingxingyichu.cn/group6/M00/D4/38/wKgBjVbT49eANRpfAIQpAPEMNmU37.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"214986"},"picUrl":"http://s2.mingxingyichu.cn/group6/M00/C8/8D/wKgBjVbKziKAKfE9AAlEoMdEcR858.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s4.mingxingyichu.cn/group6/M00/C0/4F/wKgBjVbD6POAIw0_AAeV5yAucD042.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"歌手汪苏泷","userAvatar":"http://s4.mingxingyichu.cn/group6/M00/C0/4F/wKgBjVbD6POAIw0_AAeV5yAucD042.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":3018604,"actionType":"detail"},"roleIcons":["http://m5.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"明星"}},{"component":{"userName":"啦啦小牛","description":"擅长打造独一无二的搭配风格","isFollow":"0","userId":9927979,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216908"},"picUrl":"http://s2.mingxingyichu.cn/group6/M00/F0/8A/wKgBjVbnw9yAM5YrAAemijdpyA846.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216671"},"picUrl":"http://s6.mingxingyichu.cn/group5/M00/AD/6F/wKgBf1bjoWaABCUiAAT8cLxHjrY58.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216299"},"picUrl":"http://s3.mingxingyichu.cn/group6/M00/E3/91/wKgBjVbeklOABDtFAAsQ7iW7LmY19.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s2.mingxingyichu.cn/group5/M00/49/39/wKgBf1aA5-GAedndAAAwxig9HTA25.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"啦啦小牛","userAvatar":"http://s2.mingxingyichu.cn/group5/M00/49/39/wKgBf1aA5-GAedndAAAwxig9HTA25.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":9927979,"actionType":"detail"},"roleIcons":["http://mxyc.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"AvaFoo","description":"上海一朵花，擅长经典独特搭配","isFollow":"0","userId":5357820,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"485124"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/9B/44/wKgBjVggC02ATL5NAAuTxMvKX3459.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"466875"},"picUrl":"http://s3.mingxingyichu.cn/group5/M00/68/A5/wKgBf1e_1vKAR90-AAf3m4V2jn073.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"466021"},"picUrl":"http://s4.mingxingyichu.cn/group6/M00/55/DA/wKgBjFe7H92AbQpgAAdZOof7J-k19.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s0.mingxingyichu.cn/group6/M00/93/7D/wKgBjVXZfqCAIsvAAAG4Ny4IIBE08.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"AvaFoo","userAvatar":"http://s0.mingxingyichu.cn/group6/M00/93/7D/wKgBjVXZfqCAIsvAAAG4Ny4IIBE08.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":5357820,"actionType":"detail"},"roleIcons":["http://m3.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"黎洋littley","description":"韩系清新甜美风","isFollow":"0","userId":1462609,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216953"},"picUrl":"http://s3.mingxingyichu.cn/group6/M00/F1/B1/wKgBjFboxomAFwLjABJFcyUgtbM71.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215369"},"picUrl":"http://s6.mingxingyichu.cn/group5/M00/91/DC/wKgBfVbRAnOANGMuAAaz5Atv5k069.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215018"},"picUrl":"http://s6.mingxingyichu.cn/group5/M00/89/3D/wKgBfVbLWZiASyZpABB9DsBS2HE86.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/93/CA/wKgBf1bRAf-AC7oBAAcdOH8aNjk79.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"黎洋littley","userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/93/CA/wKgBf1bRAf-AC7oBAAcdOH8aNjk79.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":1462609,"actionType":"detail"},"roleIcons":["http://m5.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"岑燕兰","description":"chic girl","isFollow":"0","userId":11972297,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215746"},"picUrl":"http://s0.mingxingyichu.cn/group5/M00/9B/9D/wKgBf1bWwnWALj8RABYLjY-asbY99.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215688"},"picUrl":"http://s5.mingxingyichu.cn/group6/M00/D8/4A/wKgBjVbWbyCAe527ACRYZ6AVG7w91.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"208479"},"picUrl":"http://s5.mingxingyichu.cn/group6/M00/83/DD/wKgBjFZ-iJCATCyEACQt8bdwHR890.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s6.mingxingyichu.cn/group6/M00/7F/F7/wKgBjVZ8_qeAEqCzAAXh42wuMBs71.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"岑燕兰","userAvatar":"http://s6.mingxingyichu.cn/group6/M00/7F/F7/wKgBjVZ8_qeAEqCzAAXh42wuMBs71.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":11972297,"actionType":"detail"},"roleIcons":["http://m2.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"程茧儿","description":"CocoonLovely完美蜕变，从这里开始","isFollow":"0","userId":12429681,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215858"},"picUrl":"http://s2.mingxingyichu.cn/group6/M00/DB/0F/wKgBjFbX8K2AZvkaAASyZydX9kw59.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"214438"},"picUrl":"http://s0.mingxingyichu.cn/group6/M00/C0/66/wKgBjVbD8MGAAawHAAvQ_7cFPQs99.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s3.mingxingyichu.cn/group6/M00/9B/EC/wKgBjFaTEvuASZZmAASq5VKFGaw78.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"程茧儿","userAvatar":"http://s3.mingxingyichu.cn/group6/M00/9B/EC/wKgBjFaTEvuASZZmAASq5VKFGaw78.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":12429681,"actionType":"detail"},"roleIcons":["http://mxyc.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"V.Charm设计师刘阳","description":"美女独立设计师，创造一切美的东西","isFollow":"0","userId":6111268,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"223058"},"picUrl":"http://s6.mingxingyichu.cn/group6/M00/16/A1/wKgBjFcUTTCATKdNAAdm1_AZ5F086.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"219097"},"picUrl":"http://s3.mingxingyichu.cn/group6/M00/14/53/wKgBjFcPpheABHdmAAoSsw37IfY48.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216887"},"picUrl":"http://s2.mingxingyichu.cn/group5/M00/AF/DD/wKgBfVbnrr2AFi_YAAj58JL53mc41.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://wx.qlogo.cn/mmopen/ajNVdqHZLLAnFcn6nZuAGibXNxHfRbgZzvJGtVwEpZYFrRmM4nvzwb1T8Nrk9HY5HRr4A7hsyCu5SJHWoWTsS3Q/0","action":{"userName":"V.Charm设计师刘阳","userAvatar":"http://wx.qlogo.cn/mmopen/ajNVdqHZLLAnFcn6nZuAGibXNxHfRbgZzvJGtVwEpZYFrRmM4nvzwb1T8Nrk9HY5HRr4A7hsyCu5SJHWoWTsS3Q/0","type":"user","id":6111268,"actionType":"detail"},"roleIcons":["http://m3.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"HUTTIONN设计师梦会停","description":"\u201d女神新装\u201c鬼才设计师","isFollow":"0","userId":12949566,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217302"},"picUrl":"http://s5.mingxingyichu.cn/group5/M00/BA/98/wKgBf1bvlGCAfbRkAAMqZ1DLEt491.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216161"},"picUrl":"http://s4.mingxingyichu.cn/group6/M00/E1/64/wKgBjVbdN1SAffU9AAKQDt8d-r070.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215719"},"picUrl":"http://s5.mingxingyichu.cn/group6/M00/D8/C6/wKgBjFbWk7CAXhZKAAG-S1UEnZs42.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s1.mingxingyichu.cn/group6/M00/BE/CC/wKgBjFbCiyOAHBuqAAKNatk2KG8330.png?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"HUTTIONN设计师梦会停","userAvatar":"http://s1.mingxingyichu.cn/group6/M00/BE/CC/wKgBjFbCiyOAHBuqAAKNatk2KG8330.png?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":12949566,"actionType":"detail"},"roleIcons":["http://m4.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"RYnn_余林浠","description":"原创女装品牌主理人，喜好多元化风格，热衷美食、旅行、穿搭。慢热易害羞却够随和。很乐于和妹子们一起分享丰富多元化的生活与穿搭。","isFollow":"0","userId":13086436,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217609"},"picUrl":"http://s1.mingxingyichu.cn/group5/M00/BC/FE/wKgBfVbzdBGAdJZiAA1ND6HPXtc52.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217095"},"picUrl":"http://s6.mingxingyichu.cn/group6/M00/F5/06/wKgBjFbqY56APuCbAA75FXrJsr068.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217039"},"picUrl":"http://mxycsku.mingxingyichu.cn/group5/M00/B5/1B/wKgBf1bpS1mASi4UABPfo0RdDmI56.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://tp2.sinaimg.cn/5790407753/180/5752131240/0","action":{"userName":"RYnn_余林浠","userAvatar":"http://tp2.sinaimg.cn/5790407753/180/5752131240/0","type":"user","id":13086436,"actionType":"detail"},"roleIcons":["http://m2.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"ZXL设计师 朱朱","description":"ZXL设计师品牌，为追求勇敢自由疯狂的生活而诞生","isFollow":"0","userId":3515911,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"219102"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/14/54/wKgBjFcPv-KAHCNWAASbN_Hm3cA00.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"218894"},"picUrl":"http://s6.mingxingyichu.cn/group6/M00/11/98/wKgBjVcMlDeAIUVBAA1HbYn5Ehs58.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"218315"},"picUrl":"http://s5.mingxingyichu.cn/group5/M00/C7/F9/wKgBfVb_wT2AYMMlABK1k_TwY8w68.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s6.mingxingyichu.cn/group6/M00/BF/C9/wKgBjVbDESOACtfPABAU3_vurzc16.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"ZXL设计师 朱朱","userAvatar":"http://s6.mingxingyichu.cn/group6/M00/BF/C9/wKgBjVbDESOACtfPABAU3_vurzc16.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":3515911,"actionType":"detail"},"roleIcons":["http://m5.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"柠宁儿","description":"五官精致 擅长古典美妆","isFollow":"0","userId":2904927,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"492656"},"picUrl":"http://s4.mingxingyichu.cn/group5/M00/53/48/wKgBfVhKvqqAYtqNAANqVozKYPE28.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"490737"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/9D/0C/wKgBjVg_yTWAHFzrABhNTRhFOKk53.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"488764"},"picUrl":"http://s3.mingxingyichu.cn/group5/M00/54/36/wKgBf1gzmMCAd2JuAAODmNRSwSM78.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s0.mingxingyichu.cn/group6/M00/9D/E6/wKgBjVhWyVSARe9DABFr9R2Vf5s15.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"柠宁儿","userAvatar":"http://s0.mingxingyichu.cn/group6/M00/9D/E6/wKgBjVhWyVSARe9DABFr9R2Vf5s15.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":2904927,"actionType":"detail"},"roleIcons":["http://m0.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"DEPOT3男裝","description":"男装设计品牌DEPOT3 ，是为年青中产阶级而设计的城市便装。","isFollow":"0","userId":12958374,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"218804"},"picUrl":"http://mxycsku.mingxingyichu.cn/group5/M00/D0/CF/wKgBf1cLQRaAXGCoAAE5mXWW7_M93.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"218580"},"picUrl":"http://s3.mingxingyichu.cn/group5/M00/CD/70/wKgBf1cF_O2AS9xTAAMP0XO12dI42.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217809"},"picUrl":"http://s4.mingxingyichu.cn/group6/M00/01/25/wKgBjFb4lQSAWEOGAACKPTkiTxE88.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s4.mingxingyichu.cn/group6/M00/C1/4D/wKgBjVbERhOAQXETAAFZ1Z_YWlE039.png?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"DEPOT3男裝","userAvatar":"http://s4.mingxingyichu.cn/group6/M00/C1/4D/wKgBjVbERhOAQXETAAFZ1Z_YWlE039.png?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":12958374,"actionType":"detail"},"roleIcons":["http://m1.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"王羽飞FF","description":"娇小MM的私人搭配师","isFollow":"0","userId":11995757,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216301"},"picUrl":"http://s0.mingxingyichu.cn/group6/M00/E3/93/wKgBjFbelQWAZEiSAATDAW4jPZg00.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215777"},"picUrl":"http://s6.mingxingyichu.cn/group6/M00/D9/FC/wKgBjVbXnlGAfnLsABw5sNbtp0Q52.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215590"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/D6/0C/wKgBjVbVFVuAAqjsAAU7Aq-1VNY12.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s5.mingxingyichu.cn/group5/M00/81/7F/wKgBf1bCy3eAGKYiAA7Ag6ZEh3Y87.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"王羽飞FF","userAvatar":"http://s5.mingxingyichu.cn/group5/M00/81/7F/wKgBf1bCy3eAGKYiAA7Ag6ZEh3Y87.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":11995757,"actionType":"detail"},"roleIcons":["http://m0.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"Vicky_辣妈","description":"美容达人","isFollow":"0","userId":2938447,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"487446"},"picUrl":"http://s3.mingxingyichu.cn/group6/M00/9C/45/wKgBjVgsY82AFc7OAAYGJNNgNA041.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"487445"},"picUrl":"http://s3.mingxingyichu.cn/group5/M00/53/F2/wKgBf1gsYw6AWDApAANrm5FYnR869.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"471702"},"picUrl":"http://s6.mingxingyichu.cn/group5/M00/4B/91/wKgBf1fai3WABqoaAA4dBBZ239E35.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://tp2.sinaimg.cn/1774041753/180/5720701292/0","action":{"userName":"Vicky_辣妈","userAvatar":"http://tp2.sinaimg.cn/1774041753/180/5720701292/0","type":"user","id":2938447,"actionType":"detail"},"roleIcons":["http://m6.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"鞋履设计师PAYNE","description":"新锐鞋履设计师品牌PLANK ATELIERS，以传统制鞋与现代设计语言结合","isFollow":"0","userId":12951634,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215201"},"picUrl":"http://s4.mingxingyichu.cn/group5/M00/8F/36/wKgBf1bOY9-ASTDmAAVE3z3LsKg36.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"214691"},"picUrl":"http://s5.mingxingyichu.cn/group6/M00/C3/E8/wKgBjFbGkCSAEeR9AAPnVVc-r4o07.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"214522"},"picUrl":"http://s2.mingxingyichu.cn/group5/M00/83/E1/wKgBf1bFH-qAPNjRAAh_GwMH-Ww02.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/7F/B4/wKgBfVbC3XWAN2xPAAOs-m1XN6w12.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"鞋履设计师PAYNE","userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/7F/B4/wKgBfVbC3XWAN2xPAAOs-m1XN6w12.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":12951634,"actionType":"detail"},"roleIcons":["http://m0.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"我只是根草","description":"极简风主义者","isFollow":"0","userId":11449254,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217540"},"picUrl":"http://s5.mingxingyichu.cn/group5/M00/BE/59/wKgBf1byicyAH16uAAyhvogFEbQ76.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217032"},"picUrl":"http://s0.mingxingyichu.cn/group6/M00/F3/56/wKgBjFbpMoGALmqQAAae1IZbN_Q26.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216967"},"picUrl":"http://s6.mingxingyichu.cn/group6/M00/F2/26/wKgBjVbo216AKv6uAA9VbM4HUwc84.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s3.mingxingyichu.cn/group5/M00/17/BE/wKgBfVZgH0KAH8-sABMI4LoisrA05.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"我只是根草","userAvatar":"http://s3.mingxingyichu.cn/group5/M00/17/BE/wKgBfVZgH0KAH8-sABMI4LoisrA05.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":11449254,"actionType":"detail"},"roleIcons":["http://m0.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"吃面面用手抓","description":"擅长韩系妆容的时尚辣妈","isFollow":"0","userId":10496740,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"228297"},"picUrl":"http://s4.mingxingyichu.cn/group5/M00/08/6F/wKgBfVd8pJaABYtYAAKvDQRfVG816.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"228186"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/49/82/wKgBjVd6BFuAHnWIAAVgjZAjGYM15.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"225295"},"picUrl":"http://s6.mingxingyichu.cn/group5/M00/E1/A5/wKgBfVcl_PCAP_cdAAUuXSzb_Zw27.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://tp2.sinaimg.cn/2689465973/180/5733017106/0","action":{"userName":"吃面面用手抓","userAvatar":"http://tp2.sinaimg.cn/2689465973/180/5733017106/0","type":"user","id":10496740,"actionType":"detail"},"roleIcons":["http://m5.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}}],"title":"衣橱达人","cache":true,"flag":"18","appApi":"/forum/star"}
     */

    private String message;
    private DataBean data;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * items : [{"component":{"userName":"Burqa Ange","description":"80后全能艺人","isFollow":"0","userId":12951489,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216105"},"picUrl":"http://s0.mingxingyichu.cn/group5/M00/A2/A5/wKgBf1bc8hqAcdLxAAELyP4SdHw76.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215507"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/D4/54/wKgBjVbT7TuABTJUAAI7RQyXSAU97.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215315"},"picUrl":"http://s4.mingxingyichu.cn/group6/M00/D0/38/wKgBjFbP63qAFc7JAADyD-WEL3c27.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://wx.qlogo.cn/mmopen/DNGh0ujJaR7Nfvr11UnpD2DzkiakTCssjHrfibxKSQnTjAIfpGdNiaSb7zdUZkRBibgaWic6I5e7ibTicSlyYEARVC5Wr8aafd3Y5Mg/0","action":{"userName":"Burqa Ange","userAvatar":"http://wx.qlogo.cn/mmopen/DNGh0ujJaR7Nfvr11UnpD2DzkiakTCssjHrfibxKSQnTjAIfpGdNiaSb7zdUZkRBibgaWic6I5e7ibTicSlyYEARVC5Wr8aafd3Y5Mg/0","type":"user","id":12951489,"actionType":"detail"},"roleIcons":["http://m4.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"歌手汪苏泷","description":" 90后新生代人气偶像歌手","isFollow":"0","userId":3018604,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216270"},"picUrl":"http://s5.mingxingyichu.cn/group5/M00/A3/32/wKgBfVbeageAcIaQAAK1g_d_sJA92.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215499"},"picUrl":"http://s2.mingxingyichu.cn/group6/M00/D4/38/wKgBjVbT49eANRpfAIQpAPEMNmU37.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"214986"},"picUrl":"http://s2.mingxingyichu.cn/group6/M00/C8/8D/wKgBjVbKziKAKfE9AAlEoMdEcR858.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s4.mingxingyichu.cn/group6/M00/C0/4F/wKgBjVbD6POAIw0_AAeV5yAucD042.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"歌手汪苏泷","userAvatar":"http://s4.mingxingyichu.cn/group6/M00/C0/4F/wKgBjVbD6POAIw0_AAeV5yAucD042.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":3018604,"actionType":"detail"},"roleIcons":["http://m5.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"明星"}},{"component":{"userName":"啦啦小牛","description":"擅长打造独一无二的搭配风格","isFollow":"0","userId":9927979,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216908"},"picUrl":"http://s2.mingxingyichu.cn/group6/M00/F0/8A/wKgBjVbnw9yAM5YrAAemijdpyA846.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216671"},"picUrl":"http://s6.mingxingyichu.cn/group5/M00/AD/6F/wKgBf1bjoWaABCUiAAT8cLxHjrY58.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216299"},"picUrl":"http://s3.mingxingyichu.cn/group6/M00/E3/91/wKgBjVbeklOABDtFAAsQ7iW7LmY19.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s2.mingxingyichu.cn/group5/M00/49/39/wKgBf1aA5-GAedndAAAwxig9HTA25.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"啦啦小牛","userAvatar":"http://s2.mingxingyichu.cn/group5/M00/49/39/wKgBf1aA5-GAedndAAAwxig9HTA25.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":9927979,"actionType":"detail"},"roleIcons":["http://mxyc.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"AvaFoo","description":"上海一朵花，擅长经典独特搭配","isFollow":"0","userId":5357820,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"485124"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/9B/44/wKgBjVggC02ATL5NAAuTxMvKX3459.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"466875"},"picUrl":"http://s3.mingxingyichu.cn/group5/M00/68/A5/wKgBf1e_1vKAR90-AAf3m4V2jn073.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"466021"},"picUrl":"http://s4.mingxingyichu.cn/group6/M00/55/DA/wKgBjFe7H92AbQpgAAdZOof7J-k19.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s0.mingxingyichu.cn/group6/M00/93/7D/wKgBjVXZfqCAIsvAAAG4Ny4IIBE08.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"AvaFoo","userAvatar":"http://s0.mingxingyichu.cn/group6/M00/93/7D/wKgBjVXZfqCAIsvAAAG4Ny4IIBE08.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":5357820,"actionType":"detail"},"roleIcons":["http://m3.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"黎洋littley","description":"韩系清新甜美风","isFollow":"0","userId":1462609,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216953"},"picUrl":"http://s3.mingxingyichu.cn/group6/M00/F1/B1/wKgBjFboxomAFwLjABJFcyUgtbM71.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215369"},"picUrl":"http://s6.mingxingyichu.cn/group5/M00/91/DC/wKgBfVbRAnOANGMuAAaz5Atv5k069.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215018"},"picUrl":"http://s6.mingxingyichu.cn/group5/M00/89/3D/wKgBfVbLWZiASyZpABB9DsBS2HE86.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/93/CA/wKgBf1bRAf-AC7oBAAcdOH8aNjk79.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"黎洋littley","userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/93/CA/wKgBf1bRAf-AC7oBAAcdOH8aNjk79.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":1462609,"actionType":"detail"},"roleIcons":["http://m5.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"岑燕兰","description":"chic girl","isFollow":"0","userId":11972297,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215746"},"picUrl":"http://s0.mingxingyichu.cn/group5/M00/9B/9D/wKgBf1bWwnWALj8RABYLjY-asbY99.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215688"},"picUrl":"http://s5.mingxingyichu.cn/group6/M00/D8/4A/wKgBjVbWbyCAe527ACRYZ6AVG7w91.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"208479"},"picUrl":"http://s5.mingxingyichu.cn/group6/M00/83/DD/wKgBjFZ-iJCATCyEACQt8bdwHR890.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s6.mingxingyichu.cn/group6/M00/7F/F7/wKgBjVZ8_qeAEqCzAAXh42wuMBs71.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"岑燕兰","userAvatar":"http://s6.mingxingyichu.cn/group6/M00/7F/F7/wKgBjVZ8_qeAEqCzAAXh42wuMBs71.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":11972297,"actionType":"detail"},"roleIcons":["http://m2.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"程茧儿","description":"CocoonLovely完美蜕变，从这里开始","isFollow":"0","userId":12429681,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215858"},"picUrl":"http://s2.mingxingyichu.cn/group6/M00/DB/0F/wKgBjFbX8K2AZvkaAASyZydX9kw59.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"214438"},"picUrl":"http://s0.mingxingyichu.cn/group6/M00/C0/66/wKgBjVbD8MGAAawHAAvQ_7cFPQs99.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s3.mingxingyichu.cn/group6/M00/9B/EC/wKgBjFaTEvuASZZmAASq5VKFGaw78.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"程茧儿","userAvatar":"http://s3.mingxingyichu.cn/group6/M00/9B/EC/wKgBjFaTEvuASZZmAASq5VKFGaw78.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":12429681,"actionType":"detail"},"roleIcons":["http://mxyc.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"V.Charm设计师刘阳","description":"美女独立设计师，创造一切美的东西","isFollow":"0","userId":6111268,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"223058"},"picUrl":"http://s6.mingxingyichu.cn/group6/M00/16/A1/wKgBjFcUTTCATKdNAAdm1_AZ5F086.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"219097"},"picUrl":"http://s3.mingxingyichu.cn/group6/M00/14/53/wKgBjFcPpheABHdmAAoSsw37IfY48.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216887"},"picUrl":"http://s2.mingxingyichu.cn/group5/M00/AF/DD/wKgBfVbnrr2AFi_YAAj58JL53mc41.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://wx.qlogo.cn/mmopen/ajNVdqHZLLAnFcn6nZuAGibXNxHfRbgZzvJGtVwEpZYFrRmM4nvzwb1T8Nrk9HY5HRr4A7hsyCu5SJHWoWTsS3Q/0","action":{"userName":"V.Charm设计师刘阳","userAvatar":"http://wx.qlogo.cn/mmopen/ajNVdqHZLLAnFcn6nZuAGibXNxHfRbgZzvJGtVwEpZYFrRmM4nvzwb1T8Nrk9HY5HRr4A7hsyCu5SJHWoWTsS3Q/0","type":"user","id":6111268,"actionType":"detail"},"roleIcons":["http://m3.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"HUTTIONN设计师梦会停","description":"\u201d女神新装\u201c鬼才设计师","isFollow":"0","userId":12949566,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217302"},"picUrl":"http://s5.mingxingyichu.cn/group5/M00/BA/98/wKgBf1bvlGCAfbRkAAMqZ1DLEt491.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216161"},"picUrl":"http://s4.mingxingyichu.cn/group6/M00/E1/64/wKgBjVbdN1SAffU9AAKQDt8d-r070.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215719"},"picUrl":"http://s5.mingxingyichu.cn/group6/M00/D8/C6/wKgBjFbWk7CAXhZKAAG-S1UEnZs42.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s1.mingxingyichu.cn/group6/M00/BE/CC/wKgBjFbCiyOAHBuqAAKNatk2KG8330.png?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"HUTTIONN设计师梦会停","userAvatar":"http://s1.mingxingyichu.cn/group6/M00/BE/CC/wKgBjFbCiyOAHBuqAAKNatk2KG8330.png?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":12949566,"actionType":"detail"},"roleIcons":["http://m4.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"RYnn_余林浠","description":"原创女装品牌主理人，喜好多元化风格，热衷美食、旅行、穿搭。慢热易害羞却够随和。很乐于和妹子们一起分享丰富多元化的生活与穿搭。","isFollow":"0","userId":13086436,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217609"},"picUrl":"http://s1.mingxingyichu.cn/group5/M00/BC/FE/wKgBfVbzdBGAdJZiAA1ND6HPXtc52.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217095"},"picUrl":"http://s6.mingxingyichu.cn/group6/M00/F5/06/wKgBjFbqY56APuCbAA75FXrJsr068.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217039"},"picUrl":"http://mxycsku.mingxingyichu.cn/group5/M00/B5/1B/wKgBf1bpS1mASi4UABPfo0RdDmI56.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://tp2.sinaimg.cn/5790407753/180/5752131240/0","action":{"userName":"RYnn_余林浠","userAvatar":"http://tp2.sinaimg.cn/5790407753/180/5752131240/0","type":"user","id":13086436,"actionType":"detail"},"roleIcons":["http://m2.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"ZXL设计师 朱朱","description":"ZXL设计师品牌，为追求勇敢自由疯狂的生活而诞生","isFollow":"0","userId":3515911,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"219102"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/14/54/wKgBjFcPv-KAHCNWAASbN_Hm3cA00.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"218894"},"picUrl":"http://s6.mingxingyichu.cn/group6/M00/11/98/wKgBjVcMlDeAIUVBAA1HbYn5Ehs58.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"218315"},"picUrl":"http://s5.mingxingyichu.cn/group5/M00/C7/F9/wKgBfVb_wT2AYMMlABK1k_TwY8w68.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s6.mingxingyichu.cn/group6/M00/BF/C9/wKgBjVbDESOACtfPABAU3_vurzc16.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"ZXL设计师 朱朱","userAvatar":"http://s6.mingxingyichu.cn/group6/M00/BF/C9/wKgBjVbDESOACtfPABAU3_vurzc16.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":3515911,"actionType":"detail"},"roleIcons":["http://m5.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"柠宁儿","description":"五官精致 擅长古典美妆","isFollow":"0","userId":2904927,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"492656"},"picUrl":"http://s4.mingxingyichu.cn/group5/M00/53/48/wKgBfVhKvqqAYtqNAANqVozKYPE28.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"490737"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/9D/0C/wKgBjVg_yTWAHFzrABhNTRhFOKk53.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"488764"},"picUrl":"http://s3.mingxingyichu.cn/group5/M00/54/36/wKgBf1gzmMCAd2JuAAODmNRSwSM78.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s0.mingxingyichu.cn/group6/M00/9D/E6/wKgBjVhWyVSARe9DABFr9R2Vf5s15.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"柠宁儿","userAvatar":"http://s0.mingxingyichu.cn/group6/M00/9D/E6/wKgBjVhWyVSARe9DABFr9R2Vf5s15.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":2904927,"actionType":"detail"},"roleIcons":["http://m0.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"DEPOT3男裝","description":"男装设计品牌DEPOT3 ，是为年青中产阶级而设计的城市便装。","isFollow":"0","userId":12958374,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"218804"},"picUrl":"http://mxycsku.mingxingyichu.cn/group5/M00/D0/CF/wKgBf1cLQRaAXGCoAAE5mXWW7_M93.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"218580"},"picUrl":"http://s3.mingxingyichu.cn/group5/M00/CD/70/wKgBf1cF_O2AS9xTAAMP0XO12dI42.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217809"},"picUrl":"http://s4.mingxingyichu.cn/group6/M00/01/25/wKgBjFb4lQSAWEOGAACKPTkiTxE88.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s4.mingxingyichu.cn/group6/M00/C1/4D/wKgBjVbERhOAQXETAAFZ1Z_YWlE039.png?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"DEPOT3男裝","userAvatar":"http://s4.mingxingyichu.cn/group6/M00/C1/4D/wKgBjVbERhOAQXETAAFZ1Z_YWlE039.png?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":12958374,"actionType":"detail"},"roleIcons":["http://m1.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"王羽飞FF","description":"娇小MM的私人搭配师","isFollow":"0","userId":11995757,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216301"},"picUrl":"http://s0.mingxingyichu.cn/group6/M00/E3/93/wKgBjFbelQWAZEiSAATDAW4jPZg00.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215777"},"picUrl":"http://s6.mingxingyichu.cn/group6/M00/D9/FC/wKgBjVbXnlGAfnLsABw5sNbtp0Q52.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215590"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/D6/0C/wKgBjVbVFVuAAqjsAAU7Aq-1VNY12.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s5.mingxingyichu.cn/group5/M00/81/7F/wKgBf1bCy3eAGKYiAA7Ag6ZEh3Y87.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"王羽飞FF","userAvatar":"http://s5.mingxingyichu.cn/group5/M00/81/7F/wKgBf1bCy3eAGKYiAA7Ag6ZEh3Y87.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":11995757,"actionType":"detail"},"roleIcons":["http://m0.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"Vicky_辣妈","description":"美容达人","isFollow":"0","userId":2938447,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"487446"},"picUrl":"http://s3.mingxingyichu.cn/group6/M00/9C/45/wKgBjVgsY82AFc7OAAYGJNNgNA041.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"487445"},"picUrl":"http://s3.mingxingyichu.cn/group5/M00/53/F2/wKgBf1gsYw6AWDApAANrm5FYnR869.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"471702"},"picUrl":"http://s6.mingxingyichu.cn/group5/M00/4B/91/wKgBf1fai3WABqoaAA4dBBZ239E35.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://tp2.sinaimg.cn/1774041753/180/5720701292/0","action":{"userName":"Vicky_辣妈","userAvatar":"http://tp2.sinaimg.cn/1774041753/180/5720701292/0","type":"user","id":2938447,"actionType":"detail"},"roleIcons":["http://m6.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"鞋履设计师PAYNE","description":"新锐鞋履设计师品牌PLANK ATELIERS，以传统制鞋与现代设计语言结合","isFollow":"0","userId":12951634,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215201"},"picUrl":"http://s4.mingxingyichu.cn/group5/M00/8F/36/wKgBf1bOY9-ASTDmAAVE3z3LsKg36.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"214691"},"picUrl":"http://s5.mingxingyichu.cn/group6/M00/C3/E8/wKgBjFbGkCSAEeR9AAPnVVc-r4o07.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"214522"},"picUrl":"http://s2.mingxingyichu.cn/group5/M00/83/E1/wKgBf1bFH-qAPNjRAAh_GwMH-Ww02.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/7F/B4/wKgBfVbC3XWAN2xPAAOs-m1XN6w12.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"鞋履设计师PAYNE","userAvatar":"http://mxycsku.mingxingyichu.cn/group5/M00/7F/B4/wKgBfVbC3XWAN2xPAAOs-m1XN6w12.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":12951634,"actionType":"detail"},"roleIcons":["http://m0.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}},{"component":{"userName":"我只是根草","description":"极简风主义者","isFollow":"0","userId":11449254,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217540"},"picUrl":"http://s5.mingxingyichu.cn/group5/M00/BE/59/wKgBf1byicyAH16uAAyhvogFEbQ76.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"217032"},"picUrl":"http://s0.mingxingyichu.cn/group6/M00/F3/56/wKgBjFbpMoGALmqQAAae1IZbN_Q26.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216967"},"picUrl":"http://s6.mingxingyichu.cn/group6/M00/F2/26/wKgBjVbo216AKv6uAA9VbM4HUwc84.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://s3.mingxingyichu.cn/group5/M00/17/BE/wKgBfVZgH0KAH8-sABMI4LoisrA05.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","action":{"userName":"我只是根草","userAvatar":"http://s3.mingxingyichu.cn/group5/M00/17/BE/wKgBfVZgH0KAH8-sABMI4LoisrA05.jpeg?imageMogr2/thumbnail/120x%3E/quality/95","type":"user","id":11449254,"actionType":"detail"},"roleIcons":["http://m0.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}},{"component":{"userName":"吃面面用手抓","description":"擅长韩系妆容的时尚辣妈","isFollow":"0","userId":10496740,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"228297"},"picUrl":"http://s4.mingxingyichu.cn/group5/M00/08/6F/wKgBfVd8pJaABYtYAAKvDQRfVG816.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"228186"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/49/82/wKgBjVd6BFuAHnWIAAVgjZAjGYM15.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"225295"},"picUrl":"http://s6.mingxingyichu.cn/group5/M00/E1/A5/wKgBfVcl_PCAP_cdAAUuXSzb_Zw27.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://tp2.sinaimg.cn/2689465973/180/5733017106/0","action":{"userName":"吃面面用手抓","userAvatar":"http://tp2.sinaimg.cn/2689465973/180/5733017106/0","type":"user","id":10496740,"actionType":"detail"},"roleIcons":["http://m5.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"时尚博主"}}]
         * title : 衣橱达人
         * cache : true
         * flag : 18
         * appApi : /forum/star
         */

        private String title;
        private boolean cache;
        private String flag;
        private String appApi;
        private List<ItemsBean> items;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public boolean isCache() {
            return cache;
        }

        public void setCache(boolean cache) {
            this.cache = cache;
        }

        public String getFlag() {
            return flag;
        }

        public void setFlag(String flag) {
            this.flag = flag;
        }

        public String getAppApi() {
            return appApi;
        }

        public void setAppApi(String appApi) {
            this.appApi = appApi;
        }

        public List<ItemsBean> getItems() {
            return items;
        }

        public void setItems(List<ItemsBean> items) {
            this.items = items;
        }

        public static class ItemsBean {
            /**
             * component : {"userName":"Burqa Ange","description":"80后全能艺人","isFollow":"0","userId":12951489,"followType":"","pics":[{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216105"},"picUrl":"http://s0.mingxingyichu.cn/group5/M00/A2/A5/wKgBf1bc8hqAcdLxAAELyP4SdHw76.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215507"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/D4/54/wKgBjVbT7TuABTJUAAI7RQyXSAU97.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215315"},"picUrl":"http://s4.mingxingyichu.cn/group6/M00/D0/38/wKgBjFbP63qAFc7JAADyD-WEL3c27.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}],"componentType":"threadUserDetail","userAvatar":"http://wx.qlogo.cn/mmopen/DNGh0ujJaR7Nfvr11UnpD2DzkiakTCssjHrfibxKSQnTjAIfpGdNiaSb7zdUZkRBibgaWic6I5e7ibTicSlyYEARVC5Wr8aafd3Y5Mg/0","action":{"userName":"Burqa Ange","userAvatar":"http://wx.qlogo.cn/mmopen/DNGh0ujJaR7Nfvr11UnpD2DzkiakTCssjHrfibxKSQnTjAIfpGdNiaSb7zdUZkRBibgaWic6I5e7ibTicSlyYEARVC5Wr8aafd3Y5Mg/0","type":"user","id":12951489,"actionType":"detail"},"roleIcons":["http://m4.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"],"userTypeName":"设计师"}
             */

            private ComponentBeanX component;

            public ComponentBeanX getComponent() {
                return component;
            }

            public void setComponent(ComponentBeanX component) {
                this.component = component;
            }

            public static class ComponentBeanX {
                /**
                 * userName : Burqa Ange
                 * description : 80后全能艺人
                 * isFollow : 0
                 * userId : 12951489
                 * followType :
                 * pics : [{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216105"},"picUrl":"http://s0.mingxingyichu.cn/group5/M00/A2/A5/wKgBf1bc8hqAcdLxAAELyP4SdHw76.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215507"},"picUrl":"http://s1.mingxingyichu.cn/group6/M00/D4/54/wKgBjVbT7TuABTJUAAI7RQyXSAU97.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}},{"width":"100","height":"100","component":{"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"215315"},"picUrl":"http://s4.mingxingyichu.cn/group6/M00/D0/38/wKgBjFbP63qAFc7JAADyD-WEL3c27.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}}]
                 * componentType : threadUserDetail
                 * userAvatar : http://wx.qlogo.cn/mmopen/DNGh0ujJaR7Nfvr11UnpD2DzkiakTCssjHrfibxKSQnTjAIfpGdNiaSb7zdUZkRBibgaWic6I5e7ibTicSlyYEARVC5Wr8aafd3Y5Mg/0
                 * action : {"userName":"Burqa Ange","userAvatar":"http://wx.qlogo.cn/mmopen/DNGh0ujJaR7Nfvr11UnpD2DzkiakTCssjHrfibxKSQnTjAIfpGdNiaSb7zdUZkRBibgaWic6I5e7ibTicSlyYEARVC5Wr8aafd3Y5Mg/0","type":"user","id":12951489,"actionType":"detail"}
                 * roleIcons : ["http://m4.mingxingyichu.cn/images/images/20140721/40e5e284-7e01-492a-a2a2-71bdd16862bd.png"]
                 * userTypeName : 设计师
                 */

                private String userName;
                private String description;
                private String isFollow;
                private int userId;
                private String followType;
                private String componentType;
                private String userAvatar;
                private ActionBean action;
                private String userTypeName;
                private List<PicsBean> pics;
                private List<String> roleIcons;

                public String getUserName() {
                    return userName;
                }

                public void setUserName(String userName) {
                    this.userName = userName;
                }

                public String getDescription() {
                    return description;
                }

                public void setDescription(String description) {
                    this.description = description;
                }

                public String getIsFollow() {
                    return isFollow;
                }

                public void setIsFollow(String isFollow) {
                    this.isFollow = isFollow;
                }

                public int getUserId() {
                    return userId;
                }

                public void setUserId(int userId) {
                    this.userId = userId;
                }

                public String getFollowType() {
                    return followType;
                }

                public void setFollowType(String followType) {
                    this.followType = followType;
                }

                public String getComponentType() {
                    return componentType;
                }

                public void setComponentType(String componentType) {
                    this.componentType = componentType;
                }

                public String getUserAvatar() {
                    return userAvatar;
                }

                public void setUserAvatar(String userAvatar) {
                    this.userAvatar = userAvatar;
                }

                public ActionBean getAction() {
                    return action;
                }

                public void setAction(ActionBean action) {
                    this.action = action;
                }

                public String getUserTypeName() {
                    return userTypeName;
                }

                public void setUserTypeName(String userTypeName) {
                    this.userTypeName = userTypeName;
                }

                public List<PicsBean> getPics() {
                    return pics;
                }

                public void setPics(List<PicsBean> pics) {
                    this.pics = pics;
                }

                public List<String> getRoleIcons() {
                    return roleIcons;
                }

                public void setRoleIcons(List<String> roleIcons) {
                    this.roleIcons = roleIcons;
                }

                public static class ActionBean {
                    /**
                     * userName : Burqa Ange
                     * userAvatar : http://wx.qlogo.cn/mmopen/DNGh0ujJaR7Nfvr11UnpD2DzkiakTCssjHrfibxKSQnTjAIfpGdNiaSb7zdUZkRBibgaWic6I5e7ibTicSlyYEARVC5Wr8aafd3Y5Mg/0
                     * type : user
                     * id : 12951489
                     * actionType : detail
                     */

                    private String userName;
                    private String userAvatar;
                    private String type;
                    private int id;
                    private String actionType;

                    public String getUserName() {
                        return userName;
                    }

                    public void setUserName(String userName) {
                        this.userName = userName;
                    }

                    public String getUserAvatar() {
                        return userAvatar;
                    }

                    public void setUserAvatar(String userAvatar) {
                        this.userAvatar = userAvatar;
                    }

                    public String getType() {
                        return type;
                    }

                    public void setType(String type) {
                        this.type = type;
                    }

                    public int getId() {
                        return id;
                    }

                    public void setId(int id) {
                        this.id = id;
                    }

                    public String getActionType() {
                        return actionType;
                    }

                    public void setActionType(String actionType) {
                        this.actionType = actionType;
                    }
                }

                public static class PicsBean {
                    /**
                     * width : 100
                     * height : 100
                     * component : {"componentType":"cell","action":{"actionType":"detail","type":"thread","id":"216105"},"picUrl":"http://s0.mingxingyichu.cn/group5/M00/A2/A5/wKgBf1bc8hqAcdLxAAELyP4SdHw76.jpeg?imageMogr2/thumbnail/200x%3E/quality/95"}
                     */

                    private String width;
                    private String height;
                    private ComponentBean component;

                    public String getWidth() {
                        return width;
                    }

                    public void setWidth(String width) {
                        this.width = width;
                    }

                    public String getHeight() {
                        return height;
                    }

                    public void setHeight(String height) {
                        this.height = height;
                    }

                    public ComponentBean getComponent() {
                        return component;
                    }

                    public void setComponent(ComponentBean component) {
                        this.component = component;
                    }

                    public static class ComponentBean {
                        /**
                         * componentType : cell
                         * action : {"actionType":"detail","type":"thread","id":"216105"}
                         * picUrl : http://s0.mingxingyichu.cn/group5/M00/A2/A5/wKgBf1bc8hqAcdLxAAELyP4SdHw76.jpeg?imageMogr2/thumbnail/200x%3E/quality/95
                         */

                        private String componentType;
                        private ActionBeanX action;
                        private String picUrl;

                        public String getComponentType() {
                            return componentType;
                        }

                        public void setComponentType(String componentType) {
                            this.componentType = componentType;
                        }

                        public ActionBeanX getAction() {
                            return action;
                        }

                        public void setAction(ActionBeanX action) {
                            this.action = action;
                        }

                        public String getPicUrl() {
                            return picUrl;
                        }

                        public void setPicUrl(String picUrl) {
                            this.picUrl = picUrl;
                        }

                        public static class ActionBeanX {
                            /**
                             * actionType : detail
                             * type : thread
                             * id : 216105
                             */

                            private String actionType;
                            private String type;
                            private String id;

                            public String getActionType() {
                                return actionType;
                            }

                            public void setActionType(String actionType) {
                                this.actionType = actionType;
                            }

                            public String getType() {
                                return type;
                            }

                            public void setType(String type) {
                                this.type = type;
                            }

                            public String getId() {
                                return id;
                            }

                            public void setId(String id) {
                                this.id = id;
                            }
                        }
                    }
                }
            }
        }
    }
}
