package com.yangshenglong.newstarwardrobe.fashion.secondpage.recommend;

import java.util.List;

/**
 * Created by VolleyYang on 16/12/22.
 */

public class BannerPageBean {


    /**
     * response : {"code":0,"msg":"success","isNew":1,"version":"","data":{"items":[{"width":"876","height":"494","component":{"componentType":"cell","picUrl":"http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}},{"component":{"componentType":"msgText","text":"【慎点！令\u201c抹茶控\u201d尖叫的抹茶美食全解读】\n对于抹茶控们来说，天下没有什么抹茶解决不了的事情，如果有，那就再来份抹茶...抹茶的淡淡香味飘荡在自己的世界，又传递给那个愿意共享之人，就像有一种爱情，虽然没有轰轰烈烈、感天动地，却简单真挚、平淡珍贵，萦绕于心、久久回味。今天推荐抹茶美食，带给你不一样的享受！","color":"51,51,51,255"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404632","description":[{"component":{"componentType":"msgText","text":"抹茶大福\n大福饼，一种点心，也称夹心糯米团，类似放大版的汤圆。但是我们要说的是抹茶大福真心太可爱，牛奶外皮+抹茶+牛奶夹心，多层口感丰富，一次性满足吃货的需求。抹茶单吃会有一点点的涩，搭配牛奶后变得细滑无比，夹心入口即溶！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"844","component":{"componentType":"cell","picUrl":"http://s6.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuweANfIRAAK2D1V08KQ41.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s6.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuweANfIRAAK2D1V08KQ41.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404634","description":[{"component":{"componentType":"msgText","text":"抹茶蛋糕\n香甜的蛋糕可以接受抹茶两种方式的奉献，可以将抹茶混入面粉，让奶油、蛋香与抹茶的味道合而为一；也可以在蛋糕制作完成之后，将抹茶撒在上面，入口时，在蛋糕起伏的表面寻找茶香。无论怎么吃，都是幸福的不要不要的！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"843","component":{"componentType":"cell","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiuxmARcqLAAMcx6caCkE04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiuxmARcqLAAMcx6caCkE04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404638","description":[{"component":{"componentType":"msgText","text":"抹茶布丁\n夏日炎炎，看到这样一份甜品，有没有凉爽舒适的感觉呢？抹茶布丁有奶味和抹茶味浓郁味道，最重要的是甜度刚好！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"846","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiuy2AX65oAAKMjROVjmM31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiuy2AX65oAAKMjROVjmM31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404642","description":[{"component":{"componentType":"msgText","text":"抹茶巧克力\n刚刚做好的巧克力，在还没有干硬之前，放在盛有抹茶的容器里翻滚，让巧克力表面粘上充分的抹茶。这样的巧克力，里面可以是各种不同的颜色，外面是绿色的，吃起来入口即化！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"846","component":{"componentType":"cell","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu0iAN0zgAAKt4xVg39U94.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu0iAN0zgAAKt4xVg39U94.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404644","description":[{"component":{"componentType":"msgText","text":"抹茶千层\n千层蛋糕开始盛行起来，千层蛋糕，由法式可丽饼加奶油完成。但是加入抹茶的千层简直是人间极品！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"550","height":"822","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu1qAYJUJAANzpoTWIxI06.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu1qAYJUJAANzpoTWIxI06.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404646","description":[{"component":{"componentType":"msgText","text":"抹茶卷\n抹茶味非常非常浓郁的蛋糕卷，抹茶爱好者一定要尝试。抹茶的醇香加上入口即化的奶油，想把最美好的世界与你分享！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"847","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu2-Afo52AAJOcXrfMlQ04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu2-Afo52AAJOcXrfMlQ04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404648","description":[{"component":{"componentType":"msgText","text":"抹茶泡芙\n抹茶泡芙是一道抹茶味的泡芙。冰冰凉的口感，吃起来有点像豆乳的感觉。味道很浓郁，配上外面的泡芙很酥脆，还有上面撒的白色的糖粉。抹茶味道融进去，很香。","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"848","component":{"componentType":"cell","picUrl":"http://s3.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu4WAJ6uDAAK0qoft7ok31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s3.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu4WAJ6uDAAK0qoft7ok31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404652","description":[{"component":{"componentType":"msgText","text":"抹茶咖啡\n抹茶咖啡是一道充盈着日式风情的花式咖啡，它应该是由追求极上咖啡的日式咖啡馆所研发的口味，除了有深浓悠远的咖啡香袭人外，还有一股清新淡然的抹茶芬芳扑鼻。","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"846","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu5WADuW6AALgu2IwYs034.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu5WADuW6AALgu2IwYs034.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}}],"embedItems":[],"tags":[{"category":"美食","id":"115","action":{"id":"115","type":"forum","actionType":"tag","tag":"美食"}},{"category":"乐活","id":"525","action":{"id":"525","type":"forum","actionType":"tag","tag":"乐活"}},{"category":"休闲时光","id":"13","action":{"id":"13","type":"forum","actionType":"tag","tag":"休闲时光"}}],"user":{"action":{"actionType":"detail","type":"user","id":"1697907"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/9A/wKgBV1QWSvqAMiFEAAASf4O5wGk024.jpg","userId":"1697907","username":"词穷小姐☂","datatime":"4个月前","isfocus":"0"},"shareAction":{"actionType":"share","type":"thread","typeId":"229503","trackValue":"thread_229503","share":{"title":"我 在明星衣橱给你推荐了一个帖子","shareType":"webpage","id":"229503","description":"精选全球好货","picUrl":"http://s2.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","detailUrl":"http://m.hichao.com/app/templates/topic_detail.html?id=229503"}},"title":"慎点！令\u201c抹茶控\u201d尖叫的抹茶美食全解读","id":"229503"}}
     */

    private ResponseBean response;

    public ResponseBean getResponse() {
        return response;
    }

    public void setResponse(ResponseBean response) {
        this.response = response;
    }

    public static class ResponseBean {
        /**
         * code : 0
         * msg : success
         * isNew : 1
         * version :
         * data : {"items":[{"width":"876","height":"494","component":{"componentType":"cell","picUrl":"http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}},{"component":{"componentType":"msgText","text":"【慎点！令\u201c抹茶控\u201d尖叫的抹茶美食全解读】\n对于抹茶控们来说，天下没有什么抹茶解决不了的事情，如果有，那就再来份抹茶...抹茶的淡淡香味飘荡在自己的世界，又传递给那个愿意共享之人，就像有一种爱情，虽然没有轰轰烈烈、感天动地，却简单真挚、平淡珍贵，萦绕于心、久久回味。今天推荐抹茶美食，带给你不一样的享受！","color":"51,51,51,255"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404632","description":[{"component":{"componentType":"msgText","text":"抹茶大福\n大福饼，一种点心，也称夹心糯米团，类似放大版的汤圆。但是我们要说的是抹茶大福真心太可爱，牛奶外皮+抹茶+牛奶夹心，多层口感丰富，一次性满足吃货的需求。抹茶单吃会有一点点的涩，搭配牛奶后变得细滑无比，夹心入口即溶！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"844","component":{"componentType":"cell","picUrl":"http://s6.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuweANfIRAAK2D1V08KQ41.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s6.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuweANfIRAAK2D1V08KQ41.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404634","description":[{"component":{"componentType":"msgText","text":"抹茶蛋糕\n香甜的蛋糕可以接受抹茶两种方式的奉献，可以将抹茶混入面粉，让奶油、蛋香与抹茶的味道合而为一；也可以在蛋糕制作完成之后，将抹茶撒在上面，入口时，在蛋糕起伏的表面寻找茶香。无论怎么吃，都是幸福的不要不要的！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"843","component":{"componentType":"cell","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiuxmARcqLAAMcx6caCkE04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiuxmARcqLAAMcx6caCkE04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404638","description":[{"component":{"componentType":"msgText","text":"抹茶布丁\n夏日炎炎，看到这样一份甜品，有没有凉爽舒适的感觉呢？抹茶布丁有奶味和抹茶味浓郁味道，最重要的是甜度刚好！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"846","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiuy2AX65oAAKMjROVjmM31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiuy2AX65oAAKMjROVjmM31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404642","description":[{"component":{"componentType":"msgText","text":"抹茶巧克力\n刚刚做好的巧克力，在还没有干硬之前，放在盛有抹茶的容器里翻滚，让巧克力表面粘上充分的抹茶。这样的巧克力，里面可以是各种不同的颜色，外面是绿色的，吃起来入口即化！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"846","component":{"componentType":"cell","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu0iAN0zgAAKt4xVg39U94.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu0iAN0zgAAKt4xVg39U94.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404644","description":[{"component":{"componentType":"msgText","text":"抹茶千层\n千层蛋糕开始盛行起来，千层蛋糕，由法式可丽饼加奶油完成。但是加入抹茶的千层简直是人间极品！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"550","height":"822","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu1qAYJUJAANzpoTWIxI06.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu1qAYJUJAANzpoTWIxI06.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404646","description":[{"component":{"componentType":"msgText","text":"抹茶卷\n抹茶味非常非常浓郁的蛋糕卷，抹茶爱好者一定要尝试。抹茶的醇香加上入口即化的奶油，想把最美好的世界与你分享！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"847","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu2-Afo52AAJOcXrfMlQ04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu2-Afo52AAJOcXrfMlQ04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404648","description":[{"component":{"componentType":"msgText","text":"抹茶泡芙\n抹茶泡芙是一道抹茶味的泡芙。冰冰凉的口感，吃起来有点像豆乳的感觉。味道很浓郁，配上外面的泡芙很酥脆，还有上面撒的白色的糖粉。抹茶味道融进去，很香。","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"848","component":{"componentType":"cell","picUrl":"http://s3.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu4WAJ6uDAAK0qoft7ok31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s3.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu4WAJ6uDAAK0qoft7ok31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404652","description":[{"component":{"componentType":"msgText","text":"抹茶咖啡\n抹茶咖啡是一道充盈着日式风情的花式咖啡，它应该是由追求极上咖啡的日式咖啡馆所研发的口味，除了有深浓悠远的咖啡香袭人外，还有一股清新淡然的抹茶芬芳扑鼻。","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"846","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu5WADuW6AALgu2IwYs034.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu5WADuW6AALgu2IwYs034.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}}],"embedItems":[],"tags":[{"category":"美食","id":"115","action":{"id":"115","type":"forum","actionType":"tag","tag":"美食"}},{"category":"乐活","id":"525","action":{"id":"525","type":"forum","actionType":"tag","tag":"乐活"}},{"category":"休闲时光","id":"13","action":{"id":"13","type":"forum","actionType":"tag","tag":"休闲时光"}}],"user":{"action":{"actionType":"detail","type":"user","id":"1697907"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/9A/wKgBV1QWSvqAMiFEAAASf4O5wGk024.jpg","userId":"1697907","username":"词穷小姐☂","datatime":"4个月前","isfocus":"0"},"shareAction":{"actionType":"share","type":"thread","typeId":"229503","trackValue":"thread_229503","share":{"title":"我 在明星衣橱给你推荐了一个帖子","shareType":"webpage","id":"229503","description":"精选全球好货","picUrl":"http://s2.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","detailUrl":"http://m.hichao.com/app/templates/topic_detail.html?id=229503"}},"title":"慎点！令\u201c抹茶控\u201d尖叫的抹茶美食全解读","id":"229503"}
         */

        private int code;
        private String msg;
        private int isNew;
        private String version;
        private DataBean data;

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public int getIsNew() {
            return isNew;
        }

        public void setIsNew(int isNew) {
            this.isNew = isNew;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public DataBean getData() {
            return data;
        }

        public void setData(DataBean data) {
            this.data = data;
        }

        public static class DataBean {
            /**
             * items : [{"width":"876","height":"494","component":{"componentType":"cell","picUrl":"http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}},{"component":{"componentType":"msgText","text":"【慎点！令\u201c抹茶控\u201d尖叫的抹茶美食全解读】\n对于抹茶控们来说，天下没有什么抹茶解决不了的事情，如果有，那就再来份抹茶...抹茶的淡淡香味飘荡在自己的世界，又传递给那个愿意共享之人，就像有一种爱情，虽然没有轰轰烈烈、感天动地，却简单真挚、平淡珍贵，萦绕于心、久久回味。今天推荐抹茶美食，带给你不一样的享受！","color":"51,51,51,255"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404632","description":[{"component":{"componentType":"msgText","text":"抹茶大福\n大福饼，一种点心，也称夹心糯米团，类似放大版的汤圆。但是我们要说的是抹茶大福真心太可爱，牛奶外皮+抹茶+牛奶夹心，多层口感丰富，一次性满足吃货的需求。抹茶单吃会有一点点的涩，搭配牛奶后变得细滑无比，夹心入口即溶！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"844","component":{"componentType":"cell","picUrl":"http://s6.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuweANfIRAAK2D1V08KQ41.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s6.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuweANfIRAAK2D1V08KQ41.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404634","description":[{"component":{"componentType":"msgText","text":"抹茶蛋糕\n香甜的蛋糕可以接受抹茶两种方式的奉献，可以将抹茶混入面粉，让奶油、蛋香与抹茶的味道合而为一；也可以在蛋糕制作完成之后，将抹茶撒在上面，入口时，在蛋糕起伏的表面寻找茶香。无论怎么吃，都是幸福的不要不要的！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"843","component":{"componentType":"cell","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiuxmARcqLAAMcx6caCkE04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiuxmARcqLAAMcx6caCkE04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404638","description":[{"component":{"componentType":"msgText","text":"抹茶布丁\n夏日炎炎，看到这样一份甜品，有没有凉爽舒适的感觉呢？抹茶布丁有奶味和抹茶味浓郁味道，最重要的是甜度刚好！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"846","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiuy2AX65oAAKMjROVjmM31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiuy2AX65oAAKMjROVjmM31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404642","description":[{"component":{"componentType":"msgText","text":"抹茶巧克力\n刚刚做好的巧克力，在还没有干硬之前，放在盛有抹茶的容器里翻滚，让巧克力表面粘上充分的抹茶。这样的巧克力，里面可以是各种不同的颜色，外面是绿色的，吃起来入口即化！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"846","component":{"componentType":"cell","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu0iAN0zgAAKt4xVg39U94.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s5.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu0iAN0zgAAKt4xVg39U94.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404644","description":[{"component":{"componentType":"msgText","text":"抹茶千层\n千层蛋糕开始盛行起来，千层蛋糕，由法式可丽饼加奶油完成。但是加入抹茶的千层简直是人间极品！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"550","height":"822","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu1qAYJUJAANzpoTWIxI06.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu1qAYJUJAANzpoTWIxI06.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404646","description":[{"component":{"componentType":"msgText","text":"抹茶卷\n抹茶味非常非常浓郁的蛋糕卷，抹茶爱好者一定要尝试。抹茶的醇香加上入口即化的奶油，想把最美好的世界与你分享！","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"847","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu2-Afo52AAJOcXrfMlQ04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu2-Afo52AAJOcXrfMlQ04.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404648","description":[{"component":{"componentType":"msgText","text":"抹茶泡芙\n抹茶泡芙是一道抹茶味的泡芙。冰冰凉的口感，吃起来有点像豆乳的感觉。味道很浓郁，配上外面的泡芙很酥脆，还有上面撒的白色的糖粉。抹茶味道融进去，很香。","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"848","component":{"componentType":"cell","picUrl":"http://s3.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu4WAJ6uDAAK0qoft7ok31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s3.mingxingyichu.cn/group6/M00/52/66/wKgBjVeiu4WAJ6uDAAK0qoft7ok31.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}},{"component":{"componentType":"subjectCell","publishDate":"4个月前","id":"1404652","description":[{"component":{"componentType":"msgText","text":"抹茶咖啡\n抹茶咖啡是一道充盈着日式风情的花式咖啡，它应该是由追求极上咖啡的日式咖啡馆所研发的口味，除了有深浓悠远的咖啡香袭人外，还有一股清新淡然的抹茶芬芳扑鼻。","color":"51,51,51,255"}}],"embedItems":[],"imgs":[{"width":"564","height":"846","component":{"componentType":"cell","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu5WADuW6AALgu2IwYs034.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s0.mingxingyichu.cn/group6/M00/52/5C/wKgBjFeiu5WADuW6AALgu2IwYs034.jpeg?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}}],"isMain":"0"}}]
             * embedItems : []
             * tags : [{"category":"美食","id":"115","action":{"id":"115","type":"forum","actionType":"tag","tag":"美食"}},{"category":"乐活","id":"525","action":{"id":"525","type":"forum","actionType":"tag","tag":"乐活"}},{"category":"休闲时光","id":"13","action":{"id":"13","type":"forum","actionType":"tag","tag":"休闲时光"}}]
             * user : {"action":{"actionType":"detail","type":"user","id":"1697907"},"userAvatar":"http://mxycsku.qiniudn.com/group1/M00/C9/9A/wKgBV1QWSvqAMiFEAAASf4O5wGk024.jpg","userId":"1697907","username":"词穷小姐☂","datatime":"4个月前","isfocus":"0"}
             * shareAction : {"actionType":"share","type":"thread","typeId":"229503","trackValue":"thread_229503","share":{"title":"我 在明星衣橱给你推荐了一个帖子","shareType":"webpage","id":"229503","description":"精选全球好货","picUrl":"http://s2.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","detailUrl":"http://m.hichao.com/app/templates/topic_detail.html?id=229503"}}
             * title : 慎点！令“抹茶控”尖叫的抹茶美食全解读
             * id : 229503
             */

            private UserBean user;
            private ShareActionBean shareAction;
            private String title;
            private String id;
            private List<ItemsBean> items;
            private List<?> embedItems;
            private List<TagsBean> tags;

            public UserBean getUser() {
                return user;
            }

            public void setUser(UserBean user) {
                this.user = user;
            }

            public ShareActionBean getShareAction() {
                return shareAction;
            }

            public void setShareAction(ShareActionBean shareAction) {
                this.shareAction = shareAction;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public List<ItemsBean> getItems() {
                return items;
            }

            public void setItems(List<ItemsBean> items) {
                this.items = items;
            }

            public List<?> getEmbedItems() {
                return embedItems;
            }

            public void setEmbedItems(List<?> embedItems) {
                this.embedItems = embedItems;
            }

            public List<TagsBean> getTags() {
                return tags;
            }

            public void setTags(List<TagsBean> tags) {
                this.tags = tags;
            }

            public static class UserBean {
                /**
                 * action : {"actionType":"detail","type":"user","id":"1697907"}
                 * userAvatar : http://mxycsku.qiniudn.com/group1/M00/C9/9A/wKgBV1QWSvqAMiFEAAASf4O5wGk024.jpg
                 * userId : 1697907
                 * username : 词穷小姐☂
                 * datatime : 4个月前
                 * isfocus : 0
                 */

                private ActionBean action;
                private String userAvatar;
                private String userId;
                private String username;
                private String datatime;
                private String isfocus;

                public ActionBean getAction() {
                    return action;
                }

                public void setAction(ActionBean action) {
                    this.action = action;
                }

                public String getUserAvatar() {
                    return userAvatar;
                }

                public void setUserAvatar(String userAvatar) {
                    this.userAvatar = userAvatar;
                }

                public String getUserId() {
                    return userId;
                }

                public void setUserId(String userId) {
                    this.userId = userId;
                }

                public String getUsername() {
                    return username;
                }

                public void setUsername(String username) {
                    this.username = username;
                }

                public String getDatatime() {
                    return datatime;
                }

                public void setDatatime(String datatime) {
                    this.datatime = datatime;
                }

                public String getIsfocus() {
                    return isfocus;
                }

                public void setIsfocus(String isfocus) {
                    this.isfocus = isfocus;
                }

                public static class ActionBean {
                    /**
                     * actionType : detail
                     * type : user
                     * id : 1697907
                     */

                    private String actionType;
                    private String type;
                    private String id;

                    public String getActionType() {
                        return actionType;
                    }

                    public void setActionType(String actionType) {
                        this.actionType = actionType;
                    }

                    public String getType() {
                        return type;
                    }

                    public void setType(String type) {
                        this.type = type;
                    }

                    public String getId() {
                        return id;
                    }

                    public void setId(String id) {
                        this.id = id;
                    }
                }
            }

            public static class ShareActionBean {
                /**
                 * actionType : share
                 * type : thread
                 * typeId : 229503
                 * trackValue : thread_229503
                 * share : {"title":"我 在明星衣橱给你推荐了一个帖子","shareType":"webpage","id":"229503","description":"精选全球好货","picUrl":"http://s2.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","detailUrl":"http://m.hichao.com/app/templates/topic_detail.html?id=229503"}
                 */

                private String actionType;
                private String type;
                private String typeId;
                private String trackValue;
                private ShareBean share;

                public String getActionType() {
                    return actionType;
                }

                public void setActionType(String actionType) {
                    this.actionType = actionType;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getTypeId() {
                    return typeId;
                }

                public void setTypeId(String typeId) {
                    this.typeId = typeId;
                }

                public String getTrackValue() {
                    return trackValue;
                }

                public void setTrackValue(String trackValue) {
                    this.trackValue = trackValue;
                }

                public ShareBean getShare() {
                    return share;
                }

                public void setShare(ShareBean share) {
                    this.share = share;
                }

                public static class ShareBean {
                    /**
                     * title : 我 在明星衣橱给你推荐了一个帖子
                     * shareType : webpage
                     * id : 229503
                     * description : 精选全球好货
                     * picUrl : http://s2.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95
                     * detailUrl : http://m.hichao.com/app/templates/topic_detail.html?id=229503
                     */

                    private String title;
                    private String shareType;
                    private String id;
                    private String description;
                    private String picUrl;
                    private String detailUrl;

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getShareType() {
                        return shareType;
                    }

                    public void setShareType(String shareType) {
                        this.shareType = shareType;
                    }

                    public String getId() {
                        return id;
                    }

                    public void setId(String id) {
                        this.id = id;
                    }

                    public String getDescription() {
                        return description;
                    }

                    public void setDescription(String description) {
                        this.description = description;
                    }

                    public String getPicUrl() {
                        return picUrl;
                    }

                    public void setPicUrl(String picUrl) {
                        this.picUrl = picUrl;
                    }

                    public String getDetailUrl() {
                        return detailUrl;
                    }

                    public void setDetailUrl(String detailUrl) {
                        this.detailUrl = detailUrl;
                    }
                }
            }

            public static class ItemsBean {
                /**
                 * width : 876
                 * height : 494
                 * component : {"componentType":"cell","picUrl":"http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"showBigPic","picUrl":"http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}}
                 */

                private String width;
                private String height;
                private ComponentBean component;

                public String getWidth() {
                    return width;
                }

                public void setWidth(String width) {
                    this.width = width;
                }

                public String getHeight() {
                    return height;
                }

                public void setHeight(String height) {
                    this.height = height;
                }

                public ComponentBean getComponent() {
                    return component;
                }

                public void setComponent(ComponentBean component) {
                    this.component = component;
                }

                public static class ComponentBean {
                    /**
                     * componentType : cell
                     * picUrl : http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95
                     * action : {"actionType":"showBigPic","picUrl":"http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95","noSaveButton":"0"}
                     */

                    private String componentType;
                    private String picUrl;
                    private ActionBeanX action;

                    public String getComponentType() {
                        return componentType;
                    }

                    public void setComponentType(String componentType) {
                        this.componentType = componentType;
                    }

                    public String getPicUrl() {
                        return picUrl;
                    }

                    public void setPicUrl(String picUrl) {
                        this.picUrl = picUrl;
                    }

                    public ActionBeanX getAction() {
                        return action;
                    }

                    public void setAction(ActionBeanX action) {
                        this.action = action;
                    }

                    public static class ActionBeanX {
                        /**
                         * actionType : showBigPic
                         * picUrl : http://s4.mingxingyichu.cn/group6/M00/52/65/wKgBjVeiuu6AF3apABXWLfe3770193.gif?imageMogr2/thumbnail/600x%3E/quality/95
                         * noSaveButton : 0
                         */

                        private String actionType;
                        private String picUrl;
                        private String noSaveButton;

                        public String getActionType() {
                            return actionType;
                        }

                        public void setActionType(String actionType) {
                            this.actionType = actionType;
                        }

                        public String getPicUrl() {
                            return picUrl;
                        }

                        public void setPicUrl(String picUrl) {
                            this.picUrl = picUrl;
                        }

                        public String getNoSaveButton() {
                            return noSaveButton;
                        }

                        public void setNoSaveButton(String noSaveButton) {
                            this.noSaveButton = noSaveButton;
                        }
                    }
                }
            }

            public static class TagsBean {
                /**
                 * category : 美食
                 * id : 115
                 * action : {"id":"115","type":"forum","actionType":"tag","tag":"美食"}
                 */

                private String category;
                private String id;
                private ActionBeanXX action;

                public String getCategory() {
                    return category;
                }

                public void setCategory(String category) {
                    this.category = category;
                }

                public String getId() {
                    return id;
                }

                public void setId(String id) {
                    this.id = id;
                }

                public ActionBeanXX getAction() {
                    return action;
                }

                public void setAction(ActionBeanXX action) {
                    this.action = action;
                }

                public static class ActionBeanXX {
                    /**
                     * id : 115
                     * type : forum
                     * actionType : tag
                     * tag : 美食
                     */

                    private String id;
                    private String type;
                    private String actionType;
                    private String tag;

                    public String getId() {
                        return id;
                    }

                    public void setId(String id) {
                        this.id = id;
                    }

                    public String getType() {
                        return type;
                    }

                    public void setType(String type) {
                        this.type = type;
                    }

                    public String getActionType() {
                        return actionType;
                    }

                    public void setActionType(String actionType) {
                        this.actionType = actionType;
                    }

                    public String getTag() {
                        return tag;
                    }

                    public void setTag(String tag) {
                        this.tag = tag;
                    }
                }
            }
        }
    }
}
