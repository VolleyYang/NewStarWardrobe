package com.yangshenglong.newstarwardrobe.search;

/**
 * Created by CST on 16/12/22.
 */

public interface SearchInformationClick {
    void getSearchInformation(String str);
}
