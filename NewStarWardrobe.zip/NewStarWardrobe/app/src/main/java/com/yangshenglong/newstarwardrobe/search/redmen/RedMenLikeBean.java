package com.yangshenglong.newstarwardrobe.search.redmen;

import java.util.List;

/**
 * Created by CST on 16/12/24.
 */

public class RedMenLikeBean {

    /**
     * response : {"code":0,"msg":"success","isNew":1,"version":"","data":{"items":[{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1年前","user":{"action":{"actionType":"detail","type":"user","id":"837043"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-06-04-e791b1dfbc0fedee496bddb37c62488a","userId":"837043","username":"明星衣橱","datatime":"1年前"},"userId":"837043","content":"陈妍希：做个Rock girl ! \nBobosnap明星衣橱联合打造","id":"343588","pics":"http://mxycsku.qiniucdn.com/group6/M00/ED/01/wKgBjVYfeZSAE5qOAAIu74qCI9A668.jpg","action":{"actionType":"detail","type":"thread","id":"343588","banner_id":"343588"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"6573"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"这个冬天，要有温度也要有风度哦。","id":"107655","pics":"http://mxycforum.qiniucdn.com/2014-11-23-5c1823a77b1904c6d51657ed375cbbb1_1","action":{"actionType":"detail","type":"thread","id":"107655","banner_id":"107655"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"4"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"初冬，阿晶家新款。😍","id":"104339","pics":"http://mxycforum.u.qiniudn.com/2014-11-07-2fa121aa1cd3c810aa5a25cad69454ab","action":{"actionType":"detail","type":"thread","id":"104339","banner_id":"104339"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"33"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"60"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/29/19/37/dze_133699423582_avatar.jpg?imageMogr2/format/WEBP","userId":"60","username":"走路撞到猫","datatime":"2年前"},"userId":"60","content":"时尚达人，黄色几何提花针织开衫","id":"321005","pics":"http://s1.mingxingyichu.cn/group3/M00/C3/D8/wKgBW1RZ_NSANIflAAM2PqQnmpk031.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"321005","banner_id":"321005"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"7503"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"小子MM也可以很美。","id":"98878","pics":"http://mxycforum.qiniucdn.com/2014-10-15-a3d19452d15d22167c5e5c038fe751bd_0","action":{"actionType":"detail","type":"thread","id":"98878","banner_id":"98878"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"1"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"复古风来袭","id":"98728","pics":"http://mxycforum.u.qiniudn.com/2014-10-14-138c4a4939ca0fd44012f883fd993be1","action":{"actionType":"detail","type":"thread","id":"98728","banner_id":"98728"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"秋季的宠儿。[针织衫外套]","id":"89863","pics":"http://mxycforum.qiniucdn.com/2014-09-12-7eeddea3b6bc4dec831f78327e6ec5cc_2","action":{"actionType":"detail","type":"thread","id":"89863","banner_id":"89863"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"1"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"中长款的条纹毛衣，这样的效果会让你更很显瘦哦。","id":"89860","pics":"http://mxycforum.qiniucdn.com/2014-09-12-dd3a6d957b57980426c7db41a2014198_0","action":{"actionType":"detail","type":"thread","id":"89860","banner_id":"89860"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"4"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"阿晶家   韩版短款百搭宽松长袖针织衫","id":"89871","pics":"http://mxycforum.u.qiniudn.com/2014-09-12-a30889ccb4c7977b6b99ce3210ddd4f3","action":{"actionType":"detail","type":"thread","id":"89871","banner_id":"89871"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"复古牛仔外套    短款夹克\n","id":"89880","pics":"http://mxycforum.u.qiniudn.com/2014-09-12-eab6a823f8b91f8b11029f6f4c98683b","action":{"actionType":"detail","type":"thread","id":"89880","banner_id":"89880"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"超爱    宽松的茧型大衣","id":"89960","pics":"http://mxycforum.qiniucdn.com/2014-09-12-b2c29f8244b3a6f503b0a7193c3c53f2_0","action":{"actionType":"detail","type":"thread","id":"89960","banner_id":"89960"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"32"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"露腰棉质横条女套装","id":"90179","pics":"http://mxycforum.qiniucdn.com/2014-09-13-8ccec65f28be2424bcf5130db92e41d9_1","action":{"actionType":"detail","type":"thread","id":"90179","banner_id":"90179"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"爱丁堡 时尚格子气质连衣裙","id":"90181","pics":"http://mxycforum.qiniucdn.com/2014-09-13-cb35416e8290f1a9c805b49475ee6570_1","action":{"actionType":"detail","type":"thread","id":"90181","banner_id":"90181"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"9"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"可以当风衣又可当连衣裙的外套哦。。","id":"90183","pics":"http://mxycforum.qiniucdn.com/2014-09-13-2b15d05a0b66a64e7eb7508e7903bf33_0","action":{"actionType":"detail","type":"thread","id":"90183","banner_id":"90183"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"铆钉小马夹短外套","id":"90186","pics":"http://mxycforum.qiniucdn.com/2014-09-13-2147d94c943a5a50c396d46bbcebd26b_0","action":{"actionType":"detail","type":"thread","id":"90186","banner_id":"90186"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"7"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"格子控这样搭","id":"90512","pics":"http://mxycforum.u.qiniudn.com/2014-09-14-b1065eb39260bccefd9531f631213297","action":{"actionType":"detail","type":"thread","id":"90512","banner_id":"90512"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"6"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"🌟百搭衬衫，🍭让每一天都有一个不一样的你","id":"90560","pics":"http://mxycforum.u.qiniudn.com/2014-09-14-0d4bd8df3e19f7eb4738991e9aef1080","action":{"actionType":"detail","type":"thread","id":"90560","banner_id":"90560"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"17"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"🎉🎉🎉各种裤子随便调💋💋","id":"90611","pics":"http://mxycforum.u.qiniudn.com/2014-09-14-fc2516968aff032272a368de08ef26ff","action":{"actionType":"detail","type":"thread","id":"90611","banner_id":"90611"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"8"}}],"flag":"18"}}
     */

    private ResponseBean response;

    public ResponseBean getResponse() {
        return response;
    }

    public void setResponse(ResponseBean response) {
        this.response = response;
    }

    public static class ResponseBean {
        /**
         * code : 0
         * msg : success
         * isNew : 1
         * version :
         * data : {"items":[{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1年前","user":{"action":{"actionType":"detail","type":"user","id":"837043"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-06-04-e791b1dfbc0fedee496bddb37c62488a","userId":"837043","username":"明星衣橱","datatime":"1年前"},"userId":"837043","content":"陈妍希：做个Rock girl ! \nBobosnap明星衣橱联合打造","id":"343588","pics":"http://mxycsku.qiniucdn.com/group6/M00/ED/01/wKgBjVYfeZSAE5qOAAIu74qCI9A668.jpg","action":{"actionType":"detail","type":"thread","id":"343588","banner_id":"343588"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"6573"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"这个冬天，要有温度也要有风度哦。","id":"107655","pics":"http://mxycforum.qiniucdn.com/2014-11-23-5c1823a77b1904c6d51657ed375cbbb1_1","action":{"actionType":"detail","type":"thread","id":"107655","banner_id":"107655"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"4"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"初冬，阿晶家新款。😍","id":"104339","pics":"http://mxycforum.u.qiniudn.com/2014-11-07-2fa121aa1cd3c810aa5a25cad69454ab","action":{"actionType":"detail","type":"thread","id":"104339","banner_id":"104339"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"33"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"60"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/29/19/37/dze_133699423582_avatar.jpg?imageMogr2/format/WEBP","userId":"60","username":"走路撞到猫","datatime":"2年前"},"userId":"60","content":"时尚达人，黄色几何提花针织开衫","id":"321005","pics":"http://s1.mingxingyichu.cn/group3/M00/C3/D8/wKgBW1RZ_NSANIflAAM2PqQnmpk031.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"321005","banner_id":"321005"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"7503"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"小子MM也可以很美。","id":"98878","pics":"http://mxycforum.qiniucdn.com/2014-10-15-a3d19452d15d22167c5e5c038fe751bd_0","action":{"actionType":"detail","type":"thread","id":"98878","banner_id":"98878"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"1"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"复古风来袭","id":"98728","pics":"http://mxycforum.u.qiniudn.com/2014-10-14-138c4a4939ca0fd44012f883fd993be1","action":{"actionType":"detail","type":"thread","id":"98728","banner_id":"98728"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"秋季的宠儿。[针织衫外套]","id":"89863","pics":"http://mxycforum.qiniucdn.com/2014-09-12-7eeddea3b6bc4dec831f78327e6ec5cc_2","action":{"actionType":"detail","type":"thread","id":"89863","banner_id":"89863"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"1"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"中长款的条纹毛衣，这样的效果会让你更很显瘦哦。","id":"89860","pics":"http://mxycforum.qiniucdn.com/2014-09-12-dd3a6d957b57980426c7db41a2014198_0","action":{"actionType":"detail","type":"thread","id":"89860","banner_id":"89860"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"4"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"阿晶家   韩版短款百搭宽松长袖针织衫","id":"89871","pics":"http://mxycforum.u.qiniudn.com/2014-09-12-a30889ccb4c7977b6b99ce3210ddd4f3","action":{"actionType":"detail","type":"thread","id":"89871","banner_id":"89871"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"复古牛仔外套    短款夹克\n","id":"89880","pics":"http://mxycforum.u.qiniudn.com/2014-09-12-eab6a823f8b91f8b11029f6f4c98683b","action":{"actionType":"detail","type":"thread","id":"89880","banner_id":"89880"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"超爱    宽松的茧型大衣","id":"89960","pics":"http://mxycforum.qiniucdn.com/2014-09-12-b2c29f8244b3a6f503b0a7193c3c53f2_0","action":{"actionType":"detail","type":"thread","id":"89960","banner_id":"89960"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"32"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"露腰棉质横条女套装","id":"90179","pics":"http://mxycforum.qiniucdn.com/2014-09-13-8ccec65f28be2424bcf5130db92e41d9_1","action":{"actionType":"detail","type":"thread","id":"90179","banner_id":"90179"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"爱丁堡 时尚格子气质连衣裙","id":"90181","pics":"http://mxycforum.qiniucdn.com/2014-09-13-cb35416e8290f1a9c805b49475ee6570_1","action":{"actionType":"detail","type":"thread","id":"90181","banner_id":"90181"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"9"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"可以当风衣又可当连衣裙的外套哦。。","id":"90183","pics":"http://mxycforum.qiniucdn.com/2014-09-13-2b15d05a0b66a64e7eb7508e7903bf33_0","action":{"actionType":"detail","type":"thread","id":"90183","banner_id":"90183"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"铆钉小马夹短外套","id":"90186","pics":"http://mxycforum.qiniucdn.com/2014-09-13-2147d94c943a5a50c396d46bbcebd26b_0","action":{"actionType":"detail","type":"thread","id":"90186","banner_id":"90186"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"7"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"格子控这样搭","id":"90512","pics":"http://mxycforum.u.qiniudn.com/2014-09-14-b1065eb39260bccefd9531f631213297","action":{"actionType":"detail","type":"thread","id":"90512","banner_id":"90512"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"6"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"🌟百搭衬衫，🍭让每一天都有一个不一样的你","id":"90560","pics":"http://mxycforum.u.qiniudn.com/2014-09-14-0d4bd8df3e19f7eb4738991e9aef1080","action":{"actionType":"detail","type":"thread","id":"90560","banner_id":"90560"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"17"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"🎉🎉🎉各种裤子随便调💋💋","id":"90611","pics":"http://mxycforum.u.qiniudn.com/2014-09-14-fc2516968aff032272a368de08ef26ff","action":{"actionType":"detail","type":"thread","id":"90611","banner_id":"90611"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"8"}}],"flag":"18"}
         */

        private int code;
        private String msg;
        private int isNew;
        private String version;
        private DataBean data;

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public int getIsNew() {
            return isNew;
        }

        public void setIsNew(int isNew) {
            this.isNew = isNew;
        }

        public String getVersion() {
            return version;
        }

        public void setVersion(String version) {
            this.version = version;
        }

        public DataBean getData() {
            return data;
        }

        public void setData(DataBean data) {
            this.data = data;
        }

        public static class DataBean {
            /**
             * items : [{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"1年前","user":{"action":{"actionType":"detail","type":"user","id":"837043"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-06-04-e791b1dfbc0fedee496bddb37c62488a","userId":"837043","username":"明星衣橱","datatime":"1年前"},"userId":"837043","content":"陈妍希：做个Rock girl ! \nBobosnap明星衣橱联合打造","id":"343588","pics":"http://mxycsku.qiniucdn.com/group6/M00/ED/01/wKgBjVYfeZSAE5qOAAIu74qCI9A668.jpg","action":{"actionType":"detail","type":"thread","id":"343588","banner_id":"343588"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"6573"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"这个冬天，要有温度也要有风度哦。","id":"107655","pics":"http://mxycforum.qiniucdn.com/2014-11-23-5c1823a77b1904c6d51657ed375cbbb1_1","action":{"actionType":"detail","type":"thread","id":"107655","banner_id":"107655"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"4"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"初冬，阿晶家新款。😍","id":"104339","pics":"http://mxycforum.u.qiniudn.com/2014-11-07-2fa121aa1cd3c810aa5a25cad69454ab","action":{"actionType":"detail","type":"thread","id":"104339","banner_id":"104339"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"33"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"60"},"userAvatar":"http://mxyc.mingxingyichu.cn/images/images/29/19/37/dze_133699423582_avatar.jpg?imageMogr2/format/WEBP","userId":"60","username":"走路撞到猫","datatime":"2年前"},"userId":"60","content":"时尚达人，黄色几何提花针织开衫","id":"321005","pics":"http://s1.mingxingyichu.cn/group3/M00/C3/D8/wKgBW1RZ_NSANIflAAM2PqQnmpk031.jpg?imageMogr2/thumbnail/600x%3E/quality/95","action":{"actionType":"detail","type":"thread","id":"321005","banner_id":"321005"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"7503"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"小子MM也可以很美。","id":"98878","pics":"http://mxycforum.qiniucdn.com/2014-10-15-a3d19452d15d22167c5e5c038fe751bd_0","action":{"actionType":"detail","type":"thread","id":"98878","banner_id":"98878"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"1"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"复古风来袭","id":"98728","pics":"http://mxycforum.u.qiniudn.com/2014-10-14-138c4a4939ca0fd44012f883fd993be1","action":{"actionType":"detail","type":"thread","id":"98728","banner_id":"98728"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"秋季的宠儿。[针织衫外套]","id":"89863","pics":"http://mxycforum.qiniucdn.com/2014-09-12-7eeddea3b6bc4dec831f78327e6ec5cc_2","action":{"actionType":"detail","type":"thread","id":"89863","banner_id":"89863"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"1"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"中长款的条纹毛衣，这样的效果会让你更很显瘦哦。","id":"89860","pics":"http://mxycforum.qiniucdn.com/2014-09-12-dd3a6d957b57980426c7db41a2014198_0","action":{"actionType":"detail","type":"thread","id":"89860","banner_id":"89860"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"4"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"阿晶家   韩版短款百搭宽松长袖针织衫","id":"89871","pics":"http://mxycforum.u.qiniudn.com/2014-09-12-a30889ccb4c7977b6b99ce3210ddd4f3","action":{"actionType":"detail","type":"thread","id":"89871","banner_id":"89871"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"复古牛仔外套    短款夹克\n","id":"89880","pics":"http://mxycforum.u.qiniudn.com/2014-09-12-eab6a823f8b91f8b11029f6f4c98683b","action":{"actionType":"detail","type":"thread","id":"89880","banner_id":"89880"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"超爱    宽松的茧型大衣","id":"89960","pics":"http://mxycforum.qiniucdn.com/2014-09-12-b2c29f8244b3a6f503b0a7193c3c53f2_0","action":{"actionType":"detail","type":"thread","id":"89960","banner_id":"89960"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"32"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"露腰棉质横条女套装","id":"90179","pics":"http://mxycforum.qiniucdn.com/2014-09-13-8ccec65f28be2424bcf5130db92e41d9_1","action":{"actionType":"detail","type":"thread","id":"90179","banner_id":"90179"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"爱丁堡 时尚格子气质连衣裙","id":"90181","pics":"http://mxycforum.qiniucdn.com/2014-09-13-cb35416e8290f1a9c805b49475ee6570_1","action":{"actionType":"detail","type":"thread","id":"90181","banner_id":"90181"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"9"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"可以当风衣又可当连衣裙的外套哦。。","id":"90183","pics":"http://mxycforum.qiniucdn.com/2014-09-13-2b15d05a0b66a64e7eb7508e7903bf33_0","action":{"actionType":"detail","type":"thread","id":"90183","banner_id":"90183"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"2"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"铆钉小马夹短外套","id":"90186","pics":"http://mxycforum.qiniucdn.com/2014-09-13-2147d94c943a5a50c396d46bbcebd26b_0","action":{"actionType":"detail","type":"thread","id":"90186","banner_id":"90186"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"7"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"格子控这样搭","id":"90512","pics":"http://mxycforum.u.qiniudn.com/2014-09-14-b1065eb39260bccefd9531f631213297","action":{"actionType":"detail","type":"thread","id":"90512","banner_id":"90512"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"6"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"🌟百搭衬衫，🍭让每一天都有一个不一样的你","id":"90560","pics":"http://mxycforum.u.qiniudn.com/2014-09-14-0d4bd8df3e19f7eb4738991e9aef1080","action":{"actionType":"detail","type":"thread","id":"90560","banner_id":"90560"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"17"}},{"width":"177","height":"235","component":{"componentType":"postsListCell","datatime":"2年前","user":{"action":{"actionType":"detail","type":"user","id":"1491068"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-12-02-3f146593a0de8d35f712b5ec50f7a7d8","userId":"1491068","username":"阿晶","datatime":"2年前"},"userId":"1491068","content":"🎉🎉🎉各种裤子随便调💋💋","id":"90611","pics":"http://mxycforum.u.qiniudn.com/2014-09-14-fc2516968aff032272a368de08ef26ff","action":{"actionType":"detail","type":"thread","id":"90611","banner_id":"90611"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"1","collect_count":"8"}}]
             * flag : 18
             */

            private String flag;
            private List<ItemsBean> items;

            public String getFlag() {
                return flag;
            }

            public void setFlag(String flag) {
                this.flag = flag;
            }

            public List<ItemsBean> getItems() {
                return items;
            }

            public void setItems(List<ItemsBean> items) {
                this.items = items;
            }

            public static class ItemsBean {
                /**
                 * width : 177
                 * height : 235
                 * component : {"componentType":"postsListCell","datatime":"1年前","user":{"action":{"actionType":"detail","type":"user","id":"837043"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-06-04-e791b1dfbc0fedee496bddb37c62488a","userId":"837043","username":"明星衣橱","datatime":"1年前"},"userId":"837043","content":"陈妍希：做个Rock girl ! \nBobosnap明星衣橱联合打造","id":"343588","pics":"http://mxycsku.qiniucdn.com/group6/M00/ED/01/wKgBjVYfeZSAE5qOAAIu74qCI9A668.jpg","action":{"actionType":"detail","type":"thread","id":"343588","banner_id":"343588"},"is_live":"0","live_status":"0","live_view_count":"0","is_collect":"0","collect_count":"6573"}
                 */

                private String width;
                private String height;
                private ComponentBean component;

                public String getWidth() {
                    return width;
                }

                public void setWidth(String width) {
                    this.width = width;
                }

                public String getHeight() {
                    return height;
                }

                public void setHeight(String height) {
                    this.height = height;
                }

                public ComponentBean getComponent() {
                    return component;
                }

                public void setComponent(ComponentBean component) {
                    this.component = component;
                }

                public static class ComponentBean {
                    /**
                     * componentType : postsListCell
                     * datatime : 1年前
                     * user : {"action":{"actionType":"detail","type":"user","id":"837043"},"userAvatar":"http://mxycforum.u.qiniudn.com/2014-06-04-e791b1dfbc0fedee496bddb37c62488a","userId":"837043","username":"明星衣橱","datatime":"1年前"}
                     * userId : 837043
                     * content : 陈妍希：做个Rock girl !
                     Bobosnap明星衣橱联合打造
                     * id : 343588
                     * pics : http://mxycsku.qiniucdn.com/group6/M00/ED/01/wKgBjVYfeZSAE5qOAAIu74qCI9A668.jpg
                     * action : {"actionType":"detail","type":"thread","id":"343588","banner_id":"343588"}
                     * is_live : 0
                     * live_status : 0
                     * live_view_count : 0
                     * is_collect : 0
                     * collect_count : 6573
                     */

                    private String componentType;
                    private String datatime;
                    private UserBean user;
                    private String userId;
                    private String content;
                    private String id;
                    private String pics;
                    private ActionBeanX action;
                    private String is_live;
                    private String live_status;
                    private String live_view_count;
                    private String is_collect;
                    private String collect_count;

                    public String getComponentType() {
                        return componentType;
                    }

                    public void setComponentType(String componentType) {
                        this.componentType = componentType;
                    }

                    public String getDatatime() {
                        return datatime;
                    }

                    public void setDatatime(String datatime) {
                        this.datatime = datatime;
                    }

                    public UserBean getUser() {
                        return user;
                    }

                    public void setUser(UserBean user) {
                        this.user = user;
                    }

                    public String getUserId() {
                        return userId;
                    }

                    public void setUserId(String userId) {
                        this.userId = userId;
                    }

                    public String getContent() {
                        return content;
                    }

                    public void setContent(String content) {
                        this.content = content;
                    }

                    public String getId() {
                        return id;
                    }

                    public void setId(String id) {
                        this.id = id;
                    }

                    public String getPics() {
                        return pics;
                    }

                    public void setPics(String pics) {
                        this.pics = pics;
                    }

                    public ActionBeanX getAction() {
                        return action;
                    }

                    public void setAction(ActionBeanX action) {
                        this.action = action;
                    }

                    public String getIs_live() {
                        return is_live;
                    }

                    public void setIs_live(String is_live) {
                        this.is_live = is_live;
                    }

                    public String getLive_status() {
                        return live_status;
                    }

                    public void setLive_status(String live_status) {
                        this.live_status = live_status;
                    }

                    public String getLive_view_count() {
                        return live_view_count;
                    }

                    public void setLive_view_count(String live_view_count) {
                        this.live_view_count = live_view_count;
                    }

                    public String getIs_collect() {
                        return is_collect;
                    }

                    public void setIs_collect(String is_collect) {
                        this.is_collect = is_collect;
                    }

                    public String getCollect_count() {
                        return collect_count;
                    }

                    public void setCollect_count(String collect_count) {
                        this.collect_count = collect_count;
                    }

                    public static class UserBean {
                        /**
                         * action : {"actionType":"detail","type":"user","id":"837043"}
                         * userAvatar : http://mxycforum.u.qiniudn.com/2014-06-04-e791b1dfbc0fedee496bddb37c62488a
                         * userId : 837043
                         * username : 明星衣橱
                         * datatime : 1年前
                         */

                        private ActionBean action;
                        private String userAvatar;
                        private String userId;
                        private String username;
                        private String datatime;

                        public ActionBean getAction() {
                            return action;
                        }

                        public void setAction(ActionBean action) {
                            this.action = action;
                        }

                        public String getUserAvatar() {
                            return userAvatar;
                        }

                        public void setUserAvatar(String userAvatar) {
                            this.userAvatar = userAvatar;
                        }

                        public String getUserId() {
                            return userId;
                        }

                        public void setUserId(String userId) {
                            this.userId = userId;
                        }

                        public String getUsername() {
                            return username;
                        }

                        public void setUsername(String username) {
                            this.username = username;
                        }

                        public String getDatatime() {
                            return datatime;
                        }

                        public void setDatatime(String datatime) {
                            this.datatime = datatime;
                        }

                        public static class ActionBean {
                            /**
                             * actionType : detail
                             * type : user
                             * id : 837043
                             */

                            private String actionType;
                            private String type;
                            private String id;

                            public String getActionType() {
                                return actionType;
                            }

                            public void setActionType(String actionType) {
                                this.actionType = actionType;
                            }

                            public String getType() {
                                return type;
                            }

                            public void setType(String type) {
                                this.type = type;
                            }

                            public String getId() {
                                return id;
                            }

                            public void setId(String id) {
                                this.id = id;
                            }
                        }
                    }

                    public static class ActionBeanX {
                        /**
                         * actionType : detail
                         * type : thread
                         * id : 343588
                         * banner_id : 343588
                         */

                        private String actionType;
                        private String type;
                        private String id;
                        private String banner_id;

                        public String getActionType() {
                            return actionType;
                        }

                        public void setActionType(String actionType) {
                            this.actionType = actionType;
                        }

                        public String getType() {
                            return type;
                        }

                        public void setType(String type) {
                            this.type = type;
                        }

                        public String getId() {
                            return id;
                        }

                        public void setId(String id) {
                            this.id = id;
                        }

                        public String getBanner_id() {
                            return banner_id;
                        }

                        public void setBanner_id(String banner_id) {
                            this.banner_id = banner_id;
                        }
                    }
                }
            }
        }
    }
}
